<?php
// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

// 檢查是否收到要刪除的 customer ID
if (isset($_POST['id'])) {
    $customerID = $_POST['id'];

    // 建立與資料庫的連接
    $conn = new mysqli($servername, $username, $password, $dbname);

    // 檢查連接是否成功
    if ($conn->connect_error) {
        die("連接資料庫失敗: " . $conn->connect_error);
    }

    if ($conn->connect_error) {
        die("連接資料庫失敗: " . $conn->connect_error);
    }
    
    // 更新 customer 的 cus_vip_state 特徵為 1 (VIP)
    $sql = "UPDATE customer SET cus_vip_state = 1 WHERE cus_id = $customerID";
    
    if ($conn->query($sql) === TRUE) {
        echo "升級為 VIP 成功";
    } else {
        echo "升級為 VIP 失敗: " . $conn->error;
    }
    
    $conn->close();
}
?>  