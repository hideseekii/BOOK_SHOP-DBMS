<?php
session_start();

include "db_conn.php";



// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

// 建立資料庫連線
$conn = new mysqli($servername, $username, $password, $dbname);

$sql  = "SELECT * FROM bookstore where book_inventory < 20 ORDER bY book_id DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $books = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $books = array();
}
$stmt->close();

$sql2  = "SELECT * FROM bookstore";
$stmt2 = $conn->prepare($sql2);
$stmt2->execute();
$result2 = $stmt2->get_result();

if ($result2->num_rows > 0) {
    $books2 = $result2->fetch_all(MYSQLI_ASSOC);
} else {
    $books2 = array();
}
$bookCount = count($books2);
$stmt2->close();
if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['ISBN_submit'])){
    $isbn = $_POST['isbn'];

    $sql = "SELECT * FROM bookstore WHERE ISBN = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $isbn);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 0) {
        $errors[] = "你輸入的ISBN未存在";
    }
    if (empty($errors)) {
        $nnn = $isbn;
        header("Location: inventory.php?isbn_success=新增成功&nnn=" . urlencode($nnn));
        exit();
    }else{
        $error_message = implode("<br>", $errors);
        if(isset($_POST['ISBN_submit'])){
            header("Location: inventory.php?isbn_error=$error_message");
        }
        exit();
    }
}
if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['inventory_submit'])){
    $isbn = $_POST['ISBN'];
    $book_inventory = $_POST['book_inventory'];
    
    //檢查coupon_name是否重複
    $sql = "SELECT * FROM bookstore WHERE ISBN = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $isbn);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        $errors[] = "沒有找到輸入的ISBN，請重新輸入";
    }
    if (!preg_match("/^[1-9][0-9]*$/", $book_inventory)) {
        $errors[] = "請輸入有效的正整數";
    }
    if (empty($errors)) {
        $sql2 = "UPDATE bookstore SET book_inventory = book_inventory + ? WHERE ISBN = ?";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("is", $book_inventory, $isbn);
        if ($stmt2->execute()) {
            // 更新成功的處理
            header("Location: inventory.php?inventory_success=新增成功");
            exit();
        } else {
            echo "新增失敗: " . $conn->error;
        }
    } else {
        $error_message = implode("<br>", $errors);
        if (isset($_POST['inventory_submit'])) { 
            header("Location: inventory.php?inventory_error=$error_message"); 
        } 
        exit();
    }
}
if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['inventory_delete_submit'])){
    $isbn = $_POST['ISBN'];
    $book_inventory = $_POST['book_delete_inventory'];
    
    //檢查coupon_name是否重複
    $sql = "SELECT * FROM bookstore WHERE ISBN = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $isbn);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        $errors[] = "沒有找到輸入的ISBN，請重新輸入";
    }
    if (!preg_match("/^[1-9][0-9]*$/", $book_inventory)) {
        $errors[] = "請輸入有效的正整數";
    }
    if (empty($errors)) {
        $sql2 = "UPDATE bookstore SET book_inventory = book_inventory - ? WHERE ISBN = ?";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("is", $book_inventory, $isbn);
        if ($stmt2->execute()) {
            // 更新成功的處理
            header("Location: inventory.php?inventory_delete_success=減少成功");
            exit();
        } else {
            echo "減少失敗: " . $conn->error;
        }
    } else {
        $error_message = implode("<br>", $errors);
        if (isset($_POST['inventory_delete_submit'])) { 
            header("Location: inventory.php?inventory_delete_error=$error_message"); 
        } 
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager</title>

    <!-- bootstrap 5 CDN-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
        crossorigin="anonymous"></script>
    <style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
    .centered-heading {
		text-align: center;
	}
    .finished-button {
        background-color: gold;
        color: black;
        font-weight: bold;
        border: 1px solid black;
        padding: 5px 10px;
        cursor: pointer;
    }
    .bg-gray-100 {
    --tw-bg-opacity: 1;
    background-color: rgba(220, 221, 225, var(--tw-bg-opacity));
    }
    </style>
</head>

<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin.php" style="margin-right: 100px;">林宜叡的家</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link " href="add.php">Add</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="order.php">Order</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link active" aria-current="page" href="inventory.php">Inventory</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="customer_manage.php">Member</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="logout_admin.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <br/>
        <h1 class="centered-heading">待補貨</h1>
        <table class="table">
            <tr>
                <th class="text-center">項次</th>
                <th class="text-center">編號</th>
                <th class="text-center">書名</th>
                <th class="text-center">庫存</th>
                <th class="text-center">作業</th>
            </tr>
            <?php $count = 0;
            foreach($books as $book){
                $count++;?>
                <tr>
                    <td class="text-center">
                        <div class="bg-gray-100"><?php echo $count; ?></div>
                    </td>
                    <td class="text-center align-middle"><?php echo $book['ISBN']; ?></td>
                    <td class="text-center align-middle"><?php echo $book['book_title']; ?></td>
                    <td class="text-center align-middle"><?php echo $book['book_inventory']; ?></td>
                    <td class="text-center align-middle"><button class="finished-button" onclick="finished(<?=$book['book_id']?>)">訂購</button></td>
                </tr>
            <?php 
            }?>
            <?php if($count == 0){
                echo "<tr><td colspan='6' style='text-align: center;'>沒有找到庫存不夠的書</td></tr>";
            }?>
        </table>
        <script>
            function finished(bookId) {
                var confirmed = confirm('確認處理該訂單嗎?');
                if (confirmed) {
                    var xhr = new XMLHttpRequest();
                    var url = 'buybook.php'; // remove_cart_item.php 的 URL
                    xhr.open('POST', url, true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

                    // 處理AJAX回應
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                            // 處理後端回應
                            var response = xhr.responseText;
                            alert(response); // 可以在這裡顯示成功訊息或進行其他操作
                            // 刷新页面
                            window.location.reload();
                        }
                    };

                    // 发送 AJAX 请求，将 cartId 发送到后端进行删除操作
                    xhr.send('bookId=' + bookId);
                }
                else{
                    alert('取消處理');
                }
            }
        </script>
        <br/>
        <h1 class="centered-heading">檢查存貨</h1>
        <br/>
        <div style="display: flex; justify-content: center">
            <form action="inventory.php" method="POST"  style="font-size: 25px;">
                <label for="isbn">ISBN:</label>
                <input type="text" id="isbn" name="isbn" placeholder="輸入ISBN號碼" required>
                <button type="submit" name="ISBN_submit" class="btn btn-primary">提交</button>
            </form>
        </div>
        <?php if(isset($_GET['isbn_error'])){?>
            <div class="alert alert-danger" role="alert" style="text-align: center;">
                <?= ($_GET['isbn_error']); ?>
            </div>
        <?php
        }?> 
        <?php if(isset($_GET['isbn_success'])){?>
            <table class="table">
                <tr>
                    <th class="text-center">編號</th>
                    <th class="text-center">書名</th>
                    <th class="text-center">作者</th>
                    <th class="text-center">分類</th>
                    <th class="text-center">裝訂</th>
                    <th class="text-center">年份</th>
                    <th class="text-center">庫存</th>
                    <th class="text-center">單價</th>
                    <th class="text-center">會員價</th>
                </tr>
                <?php
                foreach($books2 as $book){
                    if($book['ISBN'] == $_GET['nnn']){?>
                        <tr>
                            <td class="text-center align-middle"><?php echo $book['ISBN']; ?></td>
                            <td class="text-center align-middle"><?php echo $book['book_title']; ?></td>
                            <td class="text-center align-middle"><?php echo $book['book_author']; ?></td>
                            <td class="text-center align-middle"><?php echo $book['book_category']; ?></td>
                            <td class="text-center align-middle"><?php echo $book['book_cover']; ?></td>
                            <td class="text-center align-middle"><?php echo $book['year_of_publication']; ?></td>
                            <td class="text-center align-middle"><?php echo $book['book_inventory']; ?></td>
                            <td class="text-center align-middle">$<?php echo $book['book_price']; ?></td>
                            <td class="text-center align-middle">$<?php echo $book['book_price_vip']; ?></td>
                        </tr><?php
                    }?>
                <?php 
                }?>
            </table><?php
        }?>
        <br/>
        <h1 class="centered-heading">存貨管理</h1>
        <div style="display: flex; justify-content: space-between ;text-align: center; ">
            <div style="flex-basis: 50%;">
                <form action="inventory.php" method="post" enctype="multipart/form-data"
                    class="shadow p-4 rounded mt-5" style="width: 100%; max-width: 50rem;">

                    <h1 class="text-center pb-5 display-4 fs-3">
                        添加書本庫存
                    </h1>
                    <?php if (isset($_GET['inventory_error'])) { ?>
                    <div class="alert alert-danger" role="alert">
                        <?= ($_GET['inventory_error']); ?>
                    </div>
                    <?php } ?>
                    <?php if (isset($_GET['inventory_success'])) { ?>
                    <div class="alert alert-success" role="alert">
                        <?= htmlspecialchars($_GET['inventory_success']); ?>
                    </div>
                    <?php } ?>
                    
                    <div class="mb-3"  style="text-align: center;">
                        <label class="form-label">
                            ISBN
                        </label>
                        <input type="text" class="form-control" value="<?=$title?>" name="ISBN" id="ISBN">
                    </div>
                    <div class="mb-3"  style="text-align: center;">
                        <label class="form-label">
                            Add
                        </label>
                        <input type="text" class="form-control" value="<?=$title?>" name="book_inventory" id="book_inventory">
                    </div>
                    <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-primary" name="inventory_submit">Add Inventory</button>
                    </div>
                </form>
            </div>
            <div style="flex-basis: 50%;">
                <form action="inventory.php" method="post" enctype="multipart/form-data"
                    class="shadow p-4 rounded mt-5" style="width: 100%; max-width: 50rem;">

                    <h1 class="text-center pb-5 display-4 fs-3">
                        減少書本庫存
                    </h1>
                    <?php if (isset($_GET['inventory_delete_error'])) { ?>
                    <div class="alert alert-danger" role="alert">
                        <?= ($_GET['inventory_delete_error']); ?>
                    </div>
                    <?php } ?>
                    <?php if (isset($_GET['inventory_delete_success'])) { ?>
                    <div class="alert alert-success" role="alert">
                        <?= htmlspecialchars($_GET['inventory_delete_success']); ?>
                    </div>
                    <?php } ?>
                    
                    <div class="mb-3"  style="text-align: center;">
                        <label class="form-label">
                            ISBN
                        </label>
                        <input type="text" class="form-control" value="<?=$title?>" name="ISBN" id="ISBN">
                    </div>
                    <div class="mb-3"  style="text-align: center;">
                        <label class="form-label">
                            Remove
                        </label>
                        <input type="text" class="form-control" value="<?=$title?>" name="book_delete_inventory" id="book_delete_inventory">
                    </div>
                    <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-primary" name="inventory_delete_submit">Remove Inventory</button>
                    </div>
                </form>
            </div>
        </div>
        <br/><br/>
        <h1 class="centered-heading">所有書籍</h1>
        <h4 class="centered-heading">共<?=$bookCount?>本</h1>
        <table class="table">
            <tr>
                <th class="text-center">項次</th>
                <th class="text-center">編號</th>
                <th class="text-center">書名</th>
                <th class="text-center">作者</th>
                <th class="text-center">分類</th>
                <th class="text-center">裝訂</th>
                <th class="text-center">年份</th>
                <th class="text-center">庫存</th>
                <th class="text-center">單價</th>
                <th class="text-center">會員價</th>
            </tr>
            <?php $count = 0;
            foreach($books2 as $book){
                $count++;?>
                <tr>
                    <td class="text-center">
                        <div class="bg-gray-100"><?php echo $count; ?></div>
                    </td>
                    <td class="text-center align-middle"><?php echo $book['ISBN']; ?></td>
                    <td class="text-center align-middle"><?php echo $book['book_title']; ?></td>
                    <td class="text-center align-middle"><?php echo $book['book_author']; ?></td>
                    <td class="text-center align-middle"><?php echo $book['book_category']; ?></td>
                    <td class="text-center align-middle"><?php echo $book['book_cover']; ?></td>
                    <td class="text-center align-middle"><?php echo $book['year_of_publication']; ?></td>
                    <td class="text-center align-middle"><?php echo $book['book_inventory']; ?></td>
                    <td class="text-center align-middle">$<?php echo $book['book_price']; ?></td>
                    <td class="text-center align-middle">$<?php echo $book['book_price_vip']; ?></td>
                </tr>
            <?php 
            }?>
        </table>
    </div>
</body>

</html>
