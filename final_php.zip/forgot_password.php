<?php
session_start();

// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

// 建立資料庫連線
$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連線是否成功
if ($conn->connect_error) {
    die("資料庫連線失敗: " . $conn->connect_error);
}

// 檢查是否有提交表單
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $account = $_POST["account"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $newPassword = $_POST["new_password"];
    $confirmPassword = $_POST["confirm_password"];

    // 檢查帳號、電子郵件和手機號碼是否正確
    $sql = "SELECT * FROM customer WHERE cus_account = '$account' AND cus_email = '$email' AND cus_phone_num = '$phone'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // 帳號、電子郵件和手機號碼驗證成功，檢查新密碼條件和確認密碼是否相符
        if (isValidPassword($newPassword) && $newPassword === $confirmPassword) {
            // 更新資料庫中的密碼
            $updateSql = "UPDATE customer SET cus_password = '$newPassword' WHERE cus_account = '$account'";
            if ($conn->query($updateSql) === TRUE) {
                // 密碼更新成功
                echo "密碼重置成功！";
                echo "<script>";
                echo "setTimeout(function() { window.location.href = 'login.php'; }, 2000);"; // 2秒後跳轉到login.php
                echo "</script>";
                exit();
            } else {
                echo "密碼重置失敗：" . $conn->error;
                exit();
            }
        } else {
            $error_msg =  "新密碼不符合要求或兩次輸入的密碼不相同！";
        }
    } else {
        $error_msg =  "帳號、電子郵件或手機號碼驗證失敗！";
    }
}

// 函式：檢查密碼是否符合要求
function isValidPassword($password) {
    // 密碼條件：至少一個大寫字母、至少一個小寫字母、至少一個數字
    $uppercase = preg_match('@[A-Z]@', $password);
    $lowercase = preg_match('@[a-z]@', $password);
    $number = preg_match('@[0-9]@', $password);
  
    if(!$uppercase || !$lowercase || !$number || strlen($password) < 5) {
        return false;
    } else {
        return true;
    }
}

// 關閉資料庫連線
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>忘記密碼</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <style>
        h2{
            text-align: center;
            font-weight: bold;
            font-size: 25px;
        }
        .input-wrapper {
            width: 320px;
            height: 250px;
            border: 3px solid #ccc;
            padding: 10px;
            margin: 0 auto;
            font-size: 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .form-group {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            padding: 5px;
        }

        .form-group label {
            width: 30%;
            margin-right: 2px;
            font-size: 18px;
        }

        .options {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }

        a{
            text-decoration:none;
        }
        
        .reset-button-wrapper {
            width: 300px; /* 與方塊框的寬度相同 */
            margin: 0 auto; /* 水平置中 */
            text-align: center; /* 文字置中 */
            /*margin-top: 10px; /* 與方塊框有一些間距 */
        }
        
        .reset-button {
            width: 100%; /* 填滿父容器的寬度 */
            font-weight: bold;
            font-size: 18px;
        }
        a:link    {color:navy;}
        a:visited {color:navy;}
        .error{
            text-align: center;
            padding: 2px;
            color: red;
        }
    </style>
    <style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
	</style>
</head>
<body>
    <div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="index.php" style="margin-right: 100px;">林董的線上書店</a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" 
		         id="navbarSupportedContent">
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="index.php">Store</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="contact.phps">Contact</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="about.php">About</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <?php if (isset($_SESSION['user'])) {?>
		          	<a class="nav-link  active" 
                        aria-current="page" 
		                href="member.php">Member</a>
		          <?php }else{ ?>
		          <a class="nav-link  active" 
                    aria-current="page" 
		            href="login.php">Login</a>
		          <?php } ?>
		        </li>
                <li class="nav-item">
		          <a class="nav-link" 
		            href="login_admin.php">Admin</a>
		        </li>
		      </ul>
		    </div>
		  </div>
		</nav>
    </div>
    <br/>
    <h2>忘記密碼</h2>
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
    <div class="input-wrapper">
        <div class="form-group">
            <label for="account">帳號:</label>
            <input type="text" name="account" id="account" required>
        </div>
        <div class="form-group">
            <label for="email">電子郵件:</label>
            <input type="email" name="email" id="email" required>
        </div>
        <div class="form-group">
            <label for="phone">手機號碼:</label>
            <input type="text" name="phone" id="phone" required>
        </div>
        <div class="form-group">
            <label for="new_password">新密碼:</label>
            <input type="password" name="new_password" id="new_password" required>
        </div>
        <div class="form-group">
            <label for="confirm_password">確認密碼:</label>
            <input type="password" name="confirm_password" id="confirm_password" required>
        </div>
    </div>
    <div class="error">
    <?php
        echo "<br>";  
        echo $error_msg; ?>
    </div>
    <div class="reset-button-wrapper">
        <input type="submit" value="重置密碼" class="reset-button">
    </div>
    </form>
</body>
</html>
