<?php

// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "UPDATE cart 
        INNER JOIN bookstore ON cart.book_id = bookstore.book_id 
        SET cart.cart_status = 'finished', bookstore.book_inventory = bookstore.book_inventory - cart.cart_num ,
        cart.order_id = (select max(order_id) from orders)
        WHERE cart.cart_status = 'unfinished'";
if ($conn->query($sql) === true) {
    echo "林董可以加飯囉！！！";
} else {
    echo "更新失败: " . $conn->error;
}

$conn->close();
?>