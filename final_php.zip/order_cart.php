<?php
// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the parameters from the AJAX request
$orderId = $_POST['orderId'];

$sql = "SELECT cart.*, bookstore.book_title FROM cart
        INNER JOIN bookstore ON cart.book_id = bookstore.book_id
        WHERE cart.order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $orderId);
if ($stmt->execute()) {
    $result = $stmt->get_result();
    $data = array(); // Create an empty array to store the fetched data
    while ($row = $result->fetch_assoc()) {
        $data[] = $row; // Add each row to the data array
    }

    // Store the data with preserved line breaks
    $output = '';
    $count = 0;
    foreach ($data as $row) {
        $count++;
        $output .= $count.": " . $row['book_title'].", " ."單價: $" .$row['unit_price'].", 數量: " .$row['cart_num'] ."\n";
    }
    echo $output;
} else {
    echo "處理失败: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>