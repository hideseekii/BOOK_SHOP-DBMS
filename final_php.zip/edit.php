<?php
session_start();

// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

// 建立資料庫連線
$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連線是否成功
if ($conn->connect_error) {
    die("資料庫連線失敗: " . $conn->connect_error);
}
$member_account = $_SESSION['user'];
$sql = "SELECT * FROM customer WHERE cus_account = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $member_account);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $member = $result->fetch_assoc();
} else {
    $member = null;
}

$errors = [];

// 檢查是否有提交表單
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newname = $_POST["newname"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $confirm = $_POST["confirm"];

    // 檢查帳號、電子郵件和手機號碼是否正確
    $sql = "SELECT * FROM customer WHERE cus_password = '$confirm'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // 檢查手機號碼是否符合格式
        if (!preg_match('/^[0-9]{10}$/', $phone)&& !empty($phone)) {
            $errors[] = "手機號碼格式不正確！";
        }
        // 檢查電子郵件格式是否正確
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)&& !empty($email)) {
            $errors[] = "電子郵件格式不正確！";
        }
        // if (empty($errors)) {
        //     if (!empty($newname)) {
        //         $updatesql1 = "UPDATE customer SET cus_name = '$newname' WHERE cus_password = '$confirm'";
        //     }
        //     if (!empty($email)) {
        //         $updatesql2 = "UPDATE customer SET cus_email = '$email' WHERE cus_password = '$confirm'";
        //     }
        //     if (!empty($phone)) {
        //         $updatesql3 = "UPDATE customer SET cus_phone_num = '$phone' WHERE cus_password = '$confirm'";
        //     }
        //     echo "修改完成";
        // }
        if (empty($errors)) {
            $updatesql = "UPDATE customer SET";
        
            if (!empty($newname)) {
                $updatesql .= " cus_name = '$newname',";
            }
            if (!empty($email)) {
                $updatesql .= " cus_email = '$email',";
            }
            if (!empty($phone)) {
                $updatesql .= " cus_phone_num = '$phone',";
            }
        
            // 移除更新语句末尾多余的逗号
            $updatesql = rtrim($updatesql, ",");
        
            // 添加 WHERE 条件
            $updatesql .= " WHERE cus_password = '$confirm'";
        
            if ($conn->query($updatesql) === TRUE) {
                echo '<script>
                    var message = "修改完成";
                    alert(message);
                    window.location.href = window.location.href; // 刷新当前页面
                </script>';
            } else {
                echo "修改失败: " . $conn->error;
            }
            
            
        }
        
    }else {
        $error_msg =  "密碼錯誤，修改失敗！";
    }
}



// 關閉資料庫連線
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>忘記密碼</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <style>
        h2{
            text-align: center;
            font-weight: bold;
            font-size: 25px;
        }
        .input-wrapper {
            width: 400px;
            height: 480px;
            border: 3px solid #ccc;
            padding: 10px;
            margin: 0 auto;
            font-size: 16px;
            display: flex;
            flex-direction: column;
            /* align-items: center; */
        }
        

        .form-group {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            padding: 5px;
        }

        .form-group label {
            width: 35%;
            margin-right: 2px;
            font-size: 18px;
        }
        .form-group input{
            width: 70%;
        }

        .options {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }

        a{
            text-decoration:none;
        }
        
        .reset-button-wrapper {
            width: 400px; /* 與方塊框的寬度相同 */
            margin: 0 auto; /* 水平置中 */
            text-align: center; /* 文字置中 */
            /* display: flex; */
            margin-top: 10px; 與方塊框有一些間距
        }
        
        .reset-button {
            width: 100%; /* 填滿父容器的寬度 */
            font-weight: bold;
            font-size: 18px;
        }
        .error{
            text-align: center;
            padding: 2px;
            color: red;
        }
    </style>
    <style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
    .input-wrapper h5{
        font-weight: bold;
    }
	</style>
</head>
<body>
    <div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="index.php" style="margin-right: 100px;">林董的線上書店</a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" 
		         id="navbarSupportedContent">
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="index.php">Store</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="contact.phps">Contact</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="about.php">About</a>
		        </li>
		        <li class="nav-item dropdown" style="margin-right: 10px;">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="img/unnamed.jpg" alt="User" class="user-icon" style="max-width: 40px; border-radius: 50%; margin-top:-5px;">
                        <span class="user-name"><?=$member['cus_name']?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown" >
                        <li style="text-align: center;"><a class="dropdown-item" href="cart.php">購物車</a></li>
						<li><hr class="dropdown-divider"></li>
						<li  style="text-align: center;"><a class="dropdown-item" href="edit.php">編輯個資</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li  style="text-align: center;"><a class="dropdown-item" href="logout.php">登出</a></li>
                    </ul>
                </li>
				<li>
					<a href="cart.php">
					<img src="img/cart.png" style="max-width: 40px; border-radius: 0%; margin-top: 10px;" >
					</a>
				</li>
		      </ul>
		    </div>
		  </div>
		</nav>
    </div>
    <br/>
    <h2><?php echo $member['cus_account']; ?>的個人資料</h2>
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
    <div class="input-wrapper">
        <h5 >目前名稱: <?php echo $member['cus_name']; ?></h5>
        <div class="form-group" style="padding-top: 5px;">
            <label for="newname">更改名稱:</label>
            <input type="text" name="newname" id="newname" style="width:100%;">
        </div>
        <p>------------------------------------------------------</p>
        <h5>目前電子郵件: <?php echo $member['cus_email']; ?></h5>
        <div class="form-group">
            <label for="email">更改電子郵件:</label>
            <input type="email" name="email" id="email">
        </div>
        <p>------------------------------------------------------</p>
        <h5>目前手機號碼: <?php echo $member['cus_phone_num']; ?></h5>
        <div class="form-group">
            <label for="phone">更改手機號碼:</label>
            <input type="text" name="phone" id="phone" >
        </div>
        <p>------------------------------------------------------</p>
        <h5>目前總消費: $<?php echo $member['cus_total_purchase']; ?></h5>
        <p>------------------------------------------------------</p>
        <h5>是否為VIP: <?php echo ($member['cus_vip_state'] == 1) ? '是' : '否'; ?></h5>

    </div>
    <div class="error">
    <?php
        // echo "<br>";  
        echo $error_msg; ?>
        <?php foreach ($errors as $error) { ?>
            <div class="error-message">
                <?php echo $error; ?>
            </div>
            <br>
        <?php } ?>
    </div>
    
    <div class="reset-button-wrapper">
        <p style="display: inline-block; font-weight: bold;">請輸入密碼: </p><input type="password" name="confirm" id="confirm" required style="width:280px; margin-left: 20px;">
        <input type="submit" value="確認修改" class="reset-button">
    </div>
    </form>
    
</body>
</html>
