<?php
// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the parameters from the AJAX request
$bookId = $_POST['book_id'];
$cusId = $_POST['cus_id'];
$unitPrice = $_POST['unit_price'];
$quantity = $_POST['quantity'];


// Insert the cart item into the database
$stmt = $conn->prepare("INSERT INTO cart (cus_id, book_id, unit_price, cart_num) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iidi", $cusId, $bookId, $unitPrice, $quantity);
if ($stmt->execute()) {
    echo "Cart item added successfully";
} else {
    echo "Error adding cart item: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
