<?php
// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the parameters from the AJAX request
$cartId = $_POST['cartId'];

$sql = "DELETE FROM cart WHERE cart_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $cartId);
if ($stmt->execute()) {
    echo "移除成功";
} else {
    echo "移除失败: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>