<?php
session_start();

if (!isset($_SESSION['user'])) {
    // 如果已經登入，可以執行一些相應的操作，例如重新導向至其他頁面
    header("Location: login.php");
    exit();
}

# Database Connection File
include "db_conn.php";

# Get All books function
$sql  = "SELECT * FROM bookstore ORDER bY book_id DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $books = $stmt->fetchAll();
}else {
   $books = 0;
}

$member_account = $_SESSION['user'];
# Get member information
$sql  = "SELECT * FROM customer WHERE cus_account=?";
$stmt = $conn->prepare($sql);
$stmt->execute([$member_account]);
 
if ($stmt->rowCount() > 0) {
    $current_member = $stmt->fetch();
}else {
    $current_member = 0;
}

# Get all Cart function
$sql  = "SELECT * FROM cart where cart_status = 'unfinished' ORDER bY cart_id";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $cart_items = $stmt->fetchAll();
}else {
	$cart_items = 0;
}

$sql  = "SELECT * FROM coupon ORDER bY coupon_id";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $coupons = $stmt->fetchAll();
}else {
    $coupons = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>結帳</title>

    <!-- bootstrap 5 CDN-->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    <style>
	.mt-5 {
    margin-top: 1.25rem;
    }

    .mt-10 {
    margin-top: 2.5rem;
    }

    .mb-2 {
    margin-bottom: 0.5rem;
    }

    .mr-2 {
    margin-right: 0.5rem;
    }

    .flex {
    display: flex;
    }

    .table {
    display: table;
    }

    .w-10 {
    width: 2.5rem;
    }

    .w-96 {
    width: 24rem;
    }

    .w-20 {
    width: 5rem;
    }

    .w-6 {
    width: 1.5rem;
    }

    .w-24 {
    width: 6rem;
    }

    .border-collapse {
    border-collapse: collapse;
    }

    .justify-center {
    justify-content: center;
    }

    .rounded {
    border-radius: 0.25rem;
    }

    .border-2 {
    border-width: 2px;
    }

    .border-white {
    --tw-border-opacity: 1;
    border-color: rgba(255, 255, 255, var(--tw-border-opacity));
    }

    .bg-pink-100 {
    --tw-bg-opacity: 1;
    background-color: rgba(252, 231, 243, var(--tw-bg-opacity));
    }

    .bg-gray-100 {
    --tw-bg-opacity: 1;
    background-color: rgba(220, 221, 225, var(--tw-bg-opacity));
    }

    .bg-red-600 {
    --tw-bg-opacity: 1;
    background-color: rgba(220, 38, 38, var(--tw-bg-opacity));
    }
    .bg-blue-500 {
        background-color: #3b82f6;
    }

    .hover:bg-blue-700:hover {
        background-color: #2563eb;
        filter: saturate(1.2) brightness(1.2); /* 增加饱和度和亮度 */
    }


    .p-5 {
    padding: 1.25rem;
    }

    .p-2 {
    padding: 0.5rem;
    }

    .py-1 {
    padding-top: 0.25rem;
    padding-bottom: 0.25rem;
    }

    .text-center {
    text-align: center;
    }

    .text-right {
    text-align: right;
    }

    .text-sm {
    font-size: 0.875rem;
    line-height: 1.25rem;
    }

    .text-xl {
    font-size: 1.25rem;
    line-height: 1.75rem;
    }

    .font-light {
    font-weight: 300;
    }

    .font-bold {
    font-weight: 700;
    }

    .text-red-600 {
    --tw-text-opacity: 1;
    color: rgba(220, 38, 38, var(--tw-text-opacity));
    }

    .text-white {
    --tw-text-opacity: 1;
    color: rgba(255, 255, 255, var(--tw-text-opacity));
    }

    .shadow-md {
    --tw-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
    }
    </style>
    <style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
	</style>
</head>
<body>
	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-light" style="position:fixed; z-index:999">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="<?php echo isset($_SESSION['user']) ? 'member.php' : 'index.php'; ?>" style="margin-right: 100px;">林董的線上書店</a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" 
		         id="navbarSupportedContent">
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="<?php echo isset($_SESSION['user']) ? 'member.php' : 'index.php'; ?>">Store</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="contact.php">Contact</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="about.php">About</a>
		        </li>
		        <li class="nav-item dropdown" style="margin-right: 10px;">
					<?php if (isset($_SESSION['user'])){?>
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="img/unnamed.jpg" alt="User" class="user-icon" style="max-width: 40px; border-radius: 50%; margin-top:-5px;">
                        <span class="user-name"><?=$current_member['cus_name']?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
					<li style="text-align: center;"><a class="dropdown-item" href="cart.php">購物車</a></li>
						<li><hr class="dropdown-divider"></li>
						<li  style="text-align: center;"><a class="dropdown-item" href="edit.php">編輯個資</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li  style="text-align: center;"><a class="dropdown-item" href="logout.php">登出</a></li>
                    </ul>
					<?php }else{?>
					<a class="nav-link" 
		            href="login.php">Login</a>
		          <?php } ?>
                </li>
				<li>
					<a href="cart.php">
					<img src="img/cart.png" style="max-width: 40px; border-radius: 0%; margin-top: 10px;" >
					</a>
				</li>
		      </ul>
		    </div>
		  </div>
		</nav>
		<br/>
        <div style="margin-top:100px;">
		<h1 class="text-center">結帳</h1>
        </div>
        <div class="flex justify-center">
            <div class="shadow-md p-5 mt-5" style="width: 70%;">
                <table class="table" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="text-center">項次</th>
                        <th class="text-center" style="width: 400px;">書名</th>
                        <th class="text-center">單價</th>
                        <th class="text-center">數量</th>
                        <th class="text-center">小計</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $totalSum = 0; // Variable to store the total sum
                    $count = 0;
                    foreach ($cart_items as $item) {
                        if ($item['cus_id'] == $current_member['cus_id']) { 
                            $subtotal = $item['unit_price'] * $item['cart_num']; // Calculate subtotal for each item
                            $totalSum += $subtotal; // Add the subtotal to the total sum
                            $count++;
                            ?>
                            <tr>
                                <td class="p-2 text-center">
                                    <div class="bg-gray-100 text-sm"><?php echo $count; ?></div>
                                </td>
                                <td class="p-2 text-center">
                                    <?php 
                                    foreach ($books as $book) {
                                        if ($book['book_id'] == $item['book_id']) {
                                            echo $book['book_title'];
                                            break; // Exit the loop once the matching book is found
                                        }
                                    }
                                    ?>
                                </td>
                                <td class="p-2 text-center">$<?php echo $item['unit_price']; ?></td>
                                <td class="p-2 text-center"><?php echo $item['cart_num']; ?></td>
                                <td class="p-2 text-center">$<?php echo $subtotal; ?></td>
                            </tr>
                    <?php }
                    } ?>
                </tbody>
                </table>
                <div class="text-center">
                    <label for="coupon-input" class="block">使用優惠碼：</label>
                    <input type="text" id="coupon-input" placeholder="請輸入優惠碼" class="border border-gray-300 px-2 py-1 mb-2" />
                    <button id="apply-button" onclick="applyCoupon()" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">確認</button>
                </div>
                <script>
                    var discount = 0;
                    var coupons = <?php echo json_encode($coupons); ?>;
                    var isCouponValid = false;
                    var couponCode;
                    var couponnum = -1;
                    function applyCoupon() {
                        var couponInput = document.getElementById("coupon-input");
                        couponCode = couponInput.value;
                        var discountMessage = document.getElementById("discount-message");
                        
                        for (var i = 0; i < coupons.length; i++) {
                            if (coupons[i]['coupon_name'] == couponCode) {
                                discount = coupons[i]['coupon_discount'];
                                couponnum = coupons[i]['coupon_id'];
                                isCouponValid = true;
                                break;
                            }
                        }

                        if(discount > <?php echo $totalSum; ?>){
                            discountMessage.textContent = "無法使用優惠碼";
                        }else if (isCouponValid) {
                            discountMessage.textContent = "已成功透過優惠碼折扣：" + discount + "元";
                            updateTotal();
                            document.getElementById("apply-button").disabled = true;
                        }else {
                            discountMessage.textContent = "優惠碼錯誤";
                        }
                    }

                    function updateTotal() {
                        var totalSpan = document.getElementById("total-span");
                        var totalSum = <?php echo $totalSum; ?>;
                        var finalTotal = totalSum - discount;
                        totalSpan.textContent = finalTotal.toFixed(3);
                    }
                </script>

                <div class="text-center mt-5">
                    <p style="font-size: 40px;">總計：$<span id="total-span" class="text-red-600 font-bold"><?php echo $totalSum?></span></p>
                    <p id="discount-message" class="text-green-500 font-bold"></p>
                </div>
                <div class="mt-10 text-center">
                    <p class="text-sm mb-2" style="font-size: 30px ;">配送方式：</p>
                    <br/>
                    <input type="radio" name="sent" id="sent-1" onclick="showAddressField()" style="transform: scale(1.5);"/>
                    <label for="sent-1" class="text-sm mr-2" style="font-size: 25px;">宅配</label>
                    <input type="radio" name="sent" id="sent-2" onclick="showAddressField()" style="transform: scale(1.5);"/>
                    <label for="sent-2" class="text-sm mr-2" style="font-size: 25px;"><a href = 'http://emap.pcsc.com.tw'>7-11超商取貨</a></label>
                    <input type="radio" name="sent" id="sent-3" onclick="showAddressField()" style="transform: scale(1.5);"/>
                    <label for="sent-3" class="text-sm" style="font-size: 25px;"><a href = 'https://www.famiport.com.tw/Web_Famiport/page/ShopQuery.aspx'>全家超商取貨</a></label>
                </div>
                <br/>
                <div id="addressField" style="display: none;" class="text-center">
                    <input type="text" id="addressInput" name="address" placeholder="請輸入地址" style="width: 500px;" class="px-4 py-2 border border-gray-300 rounded-md " onchange="setAddress()">
                </div>
                <script>
                    var address = ""; // 全域變數用於存儲地址
                    function showAddressField() {
                        var addressField = document.getElementById("addressField");
                        var selectedSent = document.querySelector('input[name="sent"]:checked');

                        if (selectedSent) {
                            addressField.style.display = "block";
                        }
                    }
                    function setAddress() {
                        var addressInput = document.getElementById("addressInput");
                        address = addressInput.value; // 將地址存入全域變數
                        console.log("地址：" + address);
                    }
                    function redirectToPage(url) {
                    window.location.href = url;
                    }
                </script>
                
                <div class="mt-10 text-center">
                    <p class="text-sm mb-2" style="font-size: 30px;">付款方式：</p>
                    <br/>
                    <input type="radio" name="method" id="method-1" onclick="setPaymentMethod('credit')" style="transform: scale(1.5);"/>
                    <label for="method-1" class="text-sm mr-2" style="font-size: 25px;">信用卡</label>
                    <input type="radio" name="method" id="method-2" onclick="setPaymentMethod('cash')" style="transform: scale(1.5);"/>
                    <label for="method-2" class="text-sm mr-2" style="font-size: 25px;">現金</label>
                </div>

                <div id="creditCardFields" style="display: none; " onsubmit="return false;">
                    <br>
                    <div class="" style="display: flex;">
                        <div class="form-group em_card_por" style="flex: 8;">
                            
                            <div class="em_card_input">
                            <label>信用卡號</label>
                                <input id="cc-number" type="tel" class="input-lg form-control cc-number" autocomplete="cc-number" placeholder="**** **** **** ****" style="padding-left: 80px;" maxlength = "16">
                                <img id="cc-type" src="https://www.hitrustpay.com.tw/view/images/card_logo/card.svg" style="width: 50px; height: 50px; position: relative; top: -25px; transform: translateY(-40%); left: 5px;">
                            </div>
                        </div>
                        <div class="form-group em_card_day" style="padding-left: 20px; flex: 5;">
                            <label>到期日（月／年）</label>
                            <input id="cc-exp" type="tel" class="form-control cc-exp" autocomplete="cc-exp" placeholder="MM / YY" maxlength="7">				    	
                        </div>
                        <div class="form-group em_card_val" style="padding-left: 20px; flex: 3;">
                            <label>驗證碼</label>
                            <input id="cc-val" type="tel" class="form-control cc-val" autocomplete="cc-val" placeholder="***" maxlength="3">
                        </div>
                    </div>
                </div>

                <script>
                    var paymentMethod;
                    function setPaymentMethod(method) {
                        if (method === 'credit') {
                        // 將變數設定為信用卡
                        paymentMethod = 'credit';
                        console.log('選擇信用卡付款');
                        document.getElementById('creditCardFields').style.display = 'block';
                        } else if (method === 'cash') {
                        // 將變數設定為現金
                        paymentMethod = 'cash';
                        console.log('選擇現金付款');
                        document.getElementById('creditCardFields').style.display = 'none';
                        }
                        
                        // 在這裡可以對選擇的付款方式做其他處理或呼叫相關函式
                    }
                </script>

                <div class="mt-10 text-center">
                    <p class="text-sm mb-2" style="font-size: 30px;">發票：</p>
                    <br/>
                    <input type="radio" name="way" id="way-1" onclick="setInvoiceway('paper')" style="transform: scale(1.5);"/>
                    <label for="way-1" class="text-sm mr-2" style="font-size: 25px;">紙本</label>
                    <input type="radio" name="way" id="way-2" onclick="setInvoiceway('carrier')" style="transform: scale(1.5);"/>
                    <label for="way-2" class="text-sm mr-2" style="font-size: 25px;">載具</label>
                    <input type="radio" name="way" id="way-3" onclick="setInvoiceway('donate')" style="transform: scale(1.5);"/>
                    <label for="way-3" class="text-sm mr-2" style="font-size: 25px;">捐贈</label>
                </div>
                <div id="carrierField" style="display: none; margin: 0 auto;" onsubmit="return false;">
                    <br>
                    <center><label for="carrierInput">請輸入您的載具：</label>
                    <input type="text" id="carrierInput"></center>
                </div>
                <script>
                    var invoiceway;
                    function setInvoiceway(way) {
                        if (way === 'paper') {
                        // 將變數設定為信用卡
                        invoiceway = 'paper';
                        console.log('選擇紙本發票');
                        } else if (way === 'carrier') {
                        // 將變數設定為現金
                        invoiceway = 'carrier';
                        console.log('選擇載具');
                        } else if (way === 'donate') {
                        // 將變數設定為現金
                        invoiceway = 'donate';
                        console.log('選擇捐贈');
                        }
                        if (way === 'carrier') {
                            document.getElementById('carrierField').style.display = 'block';
                        } else {
                            document.getElementById('carrierField').style.display = 'none';
                        }
                    }
                </script>
                <script>
                    function handleCheckout() {
                        var cusId = <?php echo $current_member['cus_id']; ?>;
                        var couponId = <?php echo $current_member['cus_id']; ?>;
                        var total = <?php echo $totalSum?>;
                        var xhr = new XMLHttpRequest();
                        var url = 'add_to_orders.php'; // 指定後端處理的URL
                        xhr.open('POST', url, true);
                        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                        // 處理AJAX回應
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                                // 處理後端回應
                                var response = xhr.responseText;
                                alert(response); // 可以在這裡顯示成功訊息或進行其他操作
                                edit();
                            }
                        };
                        var data = 'paymentMethod=' + paymentMethod + '&address=' + address + '&cus_id=' + cusId + '&couponnum=' + couponnum + '&invoiceway=' + invoiceway + '&isCouponValid=' + isCouponValid + '&total=' + total;
                        xhr.send(data);
                    }
                    function edit(){
                        var xhr = new XMLHttpRequest();
                        var url = 'update_cart.php'; // 指定后端处理的URL
                        xhr.open('POST', url, true);
                        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                        
                        // 处理AJAX响应
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                                // 处理后端响应
                                var response = xhr.responseText;
                                alert(response); // 可以在这里显示成功消息或进行其他操作
                            }
                        };
                        xhr.send(); // 不需要发送数据，只需要执行更新操作
                        window.location.href = 'member.php';
                    }

                    function Checkout() {
                        var creditCardNumber = document.getElementById("cc-number");
                        var creditCardExpiration = document.getElementById("cc-exp");
                        var creditCardCVV = document.getElementById("cc-val");

                        if (address === "") {
                            alert('請選擇配送方式');
                            return;
                        }else if (paymentMethod === undefined){
                            alert('請選擇付款方式');
                            return;
                        }else if (invoiceway === undefined){
                            alert('請選擇發票方式');
                            return; 
                        }
                        // 檢查信用卡相關欄位是否填寫（僅在選擇信用卡付款時檢查）
                        else if (paymentMethod === "credit") {
                            if (creditCardNumber.value === "") {
                                alert("請填寫信用卡號");
                                return;
                            }
                            if (creditCardExpiration.value === "") {
                                alert("請填寫信用卡到期日");
                                return;
                            }
                            if (creditCardCVV.value === "") {
                                alert("請填寫信用卡驗證碼");
                                return;
                            }
                            else{
                                handleCheckout();
                            }
                        }

                         // 檢查發票相關欄位是否填寫（僅在選擇載具發票時檢查）
                        else if (invoiceway === "carrier") {
                            var carrierInput = document.getElementById("carrierInput");
                            if (carrierInput.value === "") {
                                alert("請填寫載具");
                                return;
                            }
                            else{
                                handleCheckout();
                            }
                        }
                        
                        else{  
                            handleCheckout();
                        }
                        return false;
                    }
                        

                        // 執行結帳相關操作
                        
                </script>
                <div class="mt-10 text-center">
                    <p class="text-sm mb-2" style="font-size: 30px;" id="invoice-date"></p>
                </div>
                <p id="current-date"></p>

                <script>
                    function displayInvoiceDate() {
                        var invoiceDate = new Date();

                        var year = invoiceDate.getFullYear();
                        var month = String(invoiceDate.getMonth() + 1).padStart(2, '0'); // 月份从0开始，因此要加1，使用 padStart 补齐两位数
                        var day = String(invoiceDate.getDate()).padStart(2, '0'); // 使用 padStart 补齐两位数

                        var formattedDate = year + "-" + month + "-" + day;

                        var invoiceDateElement = document.getElementById("invoice-date");
                        invoiceDateElement.textContent = "購買日期：" + formattedDate;
                    }

                    // 在页面加载完成后调用 displayInvoiceDate 函数
                    window.onload = displayInvoiceDate;
                </script>

                <div class="text-center mt-10">
                    <button class="btn btn-primary" onclick="return Checkout()">結帳</button>
                </div>
            </div>
        </div>
</body>
</html>