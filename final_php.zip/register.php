<?php
// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

// 建立資料庫連線
$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連線是否成功
if ($conn->connect_error) {
    die("資料庫連線失敗: " . $conn->connect_error);
}

// 預設沒有錯誤訊息
$errors = [];

// 處理顧客註冊
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cus_name = $_POST["cus_name"];
    $cus_account = $_POST["cus_account"];
    $cus_password = $_POST["cus_password"];
    $cus_confirm_password = $_POST["confirm_password"];
    $cus_phone_num = $_POST["cus_phone_num"];
    $cus_email = $_POST["cus_email"];

    //檢查帳號是否重複
    $sql = "SELECT * FROM customer WHERE cus_account = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $cus_account);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "帳號已被使用，請重新輸入";
        echo "<script>";
        echo "alert('帳號已被使用，請重新輸入');";
        echo "window.location.href = window.location.href";
        echo "</script>";
        exit();

    }
    // 檢查密碼是否符合要求
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/', $cus_password)) {
        $errors[] = "密碼必須包含至少一個大寫字母、一個小寫字母和一個數字！";
    }

    // 檢查確認密碼是否一致
    if ($cus_password !== $cus_confirm_password) {
        $errors[] = "確認密碼與密碼不一致！";
    }

    // 檢查手機號碼是否符合格式
    if (!preg_match('/^[0-9]{10}$/', $cus_phone_num)) {
        $errors[] = "手機號碼格式不正確！";
    }

    // 檢查電子郵件格式是否正確
    if (!filter_var($cus_email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "電子郵件格式不正確！";
    }

    if (empty($errors)) {
        // 執行插入資料到顧客資料庫的操作
        $sql = "INSERT INTO customer (cus_name, cus_account, cus_password, cus_phone_num, cus_email) 
        VALUES ('$cus_name', '$cus_account', '$cus_password', '$cus_phone_num', '$cus_email')";
        if ($conn->query($sql) === TRUE) {
            session_start();
            $_SESSION['user'] = $cus_account; // 儲存帳號到會話中
    
            // JavaScript部分放在這裡
            echo "<script>";
            echo "var name = '" . $cus_name . "';";
            echo "var account = '" . $cus_account . "';";
            echo "alert(name + '，您好！將為您跳轉至商店首頁。');";
            echo "window.location.href = 'member.php?account=' + account;"; // 直接跳轉至目標頁面
            echo "</script>";

        } 
        else {
            echo "註冊失敗: " . $conn->error;
        }
    }
    exit();
}

// 關閉資料庫連線
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>顧客註冊</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script>
        function togglePasswordVisibility() {
            var passwordInput = document.getElementById("cus_password");
            var toggleButton = document.getElementById("toggleButton");

            if (passwordInput.type === "cus_password") {
                passwordInput.type = "text";
                toggleButton.textContent = "隱藏密碼";
            } else {
                passwordInput.type = "cus_password";
                toggleButton.textContent = "顯示密碼";
            }
        }

        function validateForm() {
        var passwordInput = document.getElementById("cus_password");
        var confirmPasswordInput = document.getElementById("confirm_password");
        var phoneInput = document.getElementById("cus_phone_num");
        var emailInput = document.getElementById("cus_email");

        // 檢查密碼是否符合要求
        if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}/.test(passwordInput.value)) {
            alert("密碼必須包含至少一個大寫字母、一個小寫字母和一個數字！");
            return false;
        }

        // 檢查確認密碼是否一致
        if (passwordInput.value !== confirmPasswordInput.value) {
            alert("確認密碼與密碼不一致！");
            return false;
        }

        // 檢查手機號碼格式是否正確
        if (!/^[0-9]{10}$/.test(phoneInput.value)) {
            alert("手機號碼格式不正確！");
            return false;
        }

        // 檢查電子郵件格式是否正確
        if (!/^\S+@\S+\.\S+$/.test(emailInput.value)) {
            alert("電子郵件格式不正確！");
            return false;
        }

        return true;
    }

    </script>
    <style>
        .password-requirements {
            display: flex;
            align-items: center;
            font-size: 15px;
            color: red;
            height: 30px;
        }

        .input-wrapper {
            width: 440px; /* 設定方塊框的寬度 */
            height: 520px; /* 設定方塊框的高度 */
            border: 3px solid #ccc;
            padding: 10px;
            margin: 0 auto; /* 將方塊框置中 */
        }
        
        /* 定義輸入欄位樣式 */
        .input-wrapper input {
            display: flex;
            width: 70%;
            padding: 10px;
            margin-bottom: 5px;
            }
        .no_br{
            display: flex;
            /* vertical-align: middle; */
            align-items: center;
        }
        /*.input-wrapper input[type="password"],
        .input-wrapper button#toggleButton {
            display: inline-block;
            vertical-align: middle;
            }*/
        .input-wrapper input[type="submit"] {
            width: 100%;
            font-size: 20px;
            display: block;
            margin: 0 auto;
            text-align: center;
            font-weight: bold;
            }
        h2 {
            font-size: 30px;
            text-align: center;
            }
    </style>
    <style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
	</style>
</head>
<body>
    <div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="index.php" style="margin-right: 100px;">林董的線上書店</a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" 
		         id="navbarSupportedContent">
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="index.php">Store</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="contact.php">Contact</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="about.php">About</a>
		        </li>
		        <li class="nav-item">
		          <?php if (isset($_SESSION['user'])) {?>
		          	<a class="nav-link  active" 
                      aria-current="page"
		             href="member.php">Member</a>
		          <?php }else{ ?>
		          <a class="nav-link  active"
                    aria-current="page"
		            href="login.php">Login</a>
		          <?php } ?>

		        </li>
		      </ul>
		    </div>
		  </div>
		</nav>
    </div>
    <br/>
    <h2 style="font-weight: bold;">顧客註冊</h2>
    <br>
    <div class = "input-wrapper">
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" onsubmit="return validateForm()">
        <label for="cus_name">使用者名稱:</label>
            <input type="text" name="cus_name" id="cus_name" required>
        <label for="cus_account">帳號:</label>
            <input type="text" name="cus_account" id="cus_account" required pattern="[a-zA-Z0-9!@#$%^&*()_-]+" title="帳號只能使用英數符號">
        <label for="cus_password">密碼:</label>
        <br>
            <input type="password" name="cus_password" id="cus_password" required style="display: inline-block;">
            <button type="button" id="toggleButton" onclick="togglePasswordVisibility()">顯示密碼</button>
        <div class="password-requirements">
            密碼必須包含至少一個大寫字母、一個小寫字母和一個數字！
        </div>
        <label for="confirm_password">再次輸入密碼:</label>
        <br>
            <input type="password" name="confirm_password" id="confirm_password" required>

        <label for="cus_phone_num">手機號碼:</label>
            <input type="text" name="cus_phone_num" id="cus_phone_num" required>
        <label for="cus_email">電子郵件:</label>
            <input type="email" name="cus_email" id="cus_email" required>
        <br>
        <?php foreach ($errors as $error) { ?>
            <div class="error-message">
                <?php echo $error; ?>
            </div>
            <br>
        <?php } ?>
        <input type="hidden" name="account" value="<?php echo $cus_account; ?>">
        <input type="submit" value="註冊">
    </form>
    </div>
</body>
</html>
