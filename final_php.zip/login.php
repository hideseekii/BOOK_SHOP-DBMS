<?php
session_start();

// 檢查是否已經登入
if (isset($_SESSION['user'])) {
    // 如果已經登入，可以執行一些相應的操作，例如重新導向至其他頁面
    header("Location: index.php");
    exit();
}


// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

// 建立資料庫連線
$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連線是否成功
if ($conn->connect_error) {
    die("資料庫連線失敗: " . $conn->connect_error);
}

// 檢查是否有提交表單
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $account = $_POST["account"];
    $password = $_POST["password"];

    // 查詢資料庫中是否有該帳號和密碼的記錄
    $sql1 = "SELECT * FROM customer WHERE cus_account = '$account' OR cus_password = '$password'";
    $result2 = $conn->query($sql1);

    $sql = "SELECT * FROM customer WHERE cus_account = '$account' AND cus_password = '$password'";
    $result = $conn->query($sql);
    // 如果有記錄，表示驗證成功
    if ($result->num_rows > 0) {
        // 儲存帳號到會話中
        $_SESSION['user'] = $account;
        
        // 登入成功，可以執行一些相應的操作，例如重新導向至其他頁面
        echo "<script>";
        echo "var account = '" . $account . "';";
        echo "alert(account + '，您好！將為您跳轉至商店首頁。');";
        echo "window.location.href = 'member.php?account=' + account;"; // 直接跳轉至目標頁面
        echo "</script>";
        exit();
    }else if ($result2->num_rows == 0){
        $error_msg = "還未註冊嗎，請先註冊！";
    }else {
        // 登入失敗，顯示錯誤訊息或進行其他處理
        $error_msg = "登入失敗，請檢查您的帳號和密碼！";
    }
}

// 關閉資料庫連線
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>顧客登入</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <style>
        h2{
            text-align: center;
            font-weight: bold;
            font-size: 25px;
        }
        .input-wrapper {
            width: 290px;
            height: 170px;
            border: 3px solid #ccc;
            padding: 10px;
            margin: 0 auto;
            font-size: 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .form-group {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            padding: 5px;
        }

        .form-group label {
            width: 30%;
            margin-right: 2px;
            font-size: 18px;
        }

        .options {
            /*display: flex;*/
            /*justify-content: space-between;*/
            margin-top: 10px;
        }
        .options .left {
            margin-right: 55px;
        }

        .options .right {
            margin-left: 55px;
        }

        a{
            text-decoration:none;
        }
        
        .login-button-wrapper {
            width: 276px; /* 與方塊框的寬度相同 */
            margin: 0 auto; /* 水平置中 */
            text-align: center; /* 文字置中 */
            margin-top: 10px; /* 與方塊框有一些間距 */
        }
        
        .login-button {
            width: 100%; /* 填滿父容器的寬度 */
            font-weight: bold;
            font-size: 18px;
        }
        a:link    {color:navy;}
        a:visited {color:navy;}
    </style>
    <style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
	</style>
</head>
<body>
    <div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="index.php" style="margin-right: 100px;">林董的線上書店</a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" 
		         id="navbarSupportedContent">
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link"  
		             href="index.php">Store</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="contact.php">Contact</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="about.php">About</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <?php if (isset($_SESSION['user'])) {?>
		          	<a class="nav-link  active" 
                      aria-current="page"
		             href="member.php">Member</a>
		          <?php }else{ ?>
		          <a class="nav-link  active" 
                    aria-current="page"
		            href="login.php">Login</a>
		          <?php } ?>
		        </li>
                <li class="nav-item">
		          <a class="nav-link" 
		            href="login_admin.php">Admin</a>
		        </li>
		      </ul>
		    </div>
		  </div>
		</nav>
    </div>
    <br/>
    <h2>顧客登入</h2>
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
    <div class="input-wrapper">
        <div class="form-group">
            <label for="account">帳號:</label>
            <input type="text" name="account" id="account" required>
        </div>
        <div class="form-group">
            <label for="password">密碼:</label>
            <input type="password" name="password" id="password" required>
        </div>
        <?php echo $error_msg; ?>
        <div class="options">
            <a href="forgot_password.php" class="left">忘記密碼</a>
            <a href="register.php" class="right">立即註冊</a>
        </div>
    </div>
    <div class="login-button-wrapper">
        <input type="submit" value="登入" class="login-button">
    </div>
    </form>
</body>
</html>
