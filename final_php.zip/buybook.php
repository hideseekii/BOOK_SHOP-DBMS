<?php
// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the parameters from the AJAX request
$bookId = $_POST['bookId'];
$sql = "UPDATE bookstore SET book_inventory=book_inventory+100 where book_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $bookId);
if ($stmt->execute()) {
    echo "處理成功";
} else {
    echo "處理失败: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>