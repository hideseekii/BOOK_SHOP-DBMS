<?php
date_default_timezone_set('Asia/Taipei');
session_start();

include "db_conn.php";

# Get all Order function
$sql  = "SELECT * FROM orders where order_status='unfinished'";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
	$orders = $stmt->fetchAll();
}else {
	$orders = 0;
}
$today = date('Y-m-d');

$sql  = "SELECT * FROM orders where order_status='finished' AND DATE(order_date) = '$today'";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
	$orders2 = $stmt->fetchAll();
}else {
	$orders2 = 0;
}

# Get all customer function
$sql  = "SELECT * FROM customer";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
	$customers = $stmt->fetchAll();
}else {
	$customers = 0;
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager</title>

    <!-- bootstrap 5 CDN-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
        crossorigin="anonymous"></script>
    <style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
    .centered-heading {
		text-align: center;
	}
    .finished-button {
        background-color: gold;
        color: black;
        font-weight: bold;
        border: 1px solid black;
        padding: 5px 10px;
        cursor: pointer;
    }
    .bg-gray-100 {
    --tw-bg-opacity: 1;
    background-color: rgba(220, 221, 225, var(--tw-bg-opacity));
    }
    </style>
</head>

<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin.php" style="margin-right: 100px;">林宜叡的家</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link " href="add.php">Add</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link active" aria-current="page" href="order.php">Order</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="inventory.php">Inventory</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="customer_manage.php">Member</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="logout_admin.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <br/>
        <h1 class="centered-heading">訂單處理</h1>
        <table class="table">
            <tr>
                <th class="text-center">項次</th>
                <th class="text-center">時間</th>
                <th class="text-center">顧客</th>
                <th class="text-center">付款</th>
                <th class="text-center">發票</th>
                <th class="text-center">地址</th>
                <th class="text-center">金額</th>
                <th class="text-center">細節</th>
                <th class="text-center">作業</th>
            </tr>
            <?php $count = 0;
            foreach($orders as $order){
                $count++;?>
                <tr>
                    <td class="text-center">
                        <div class="bg-gray-100"><?php echo $count; ?></div>
                    </td>
                    <td class="text-center align-middle"><?php echo $order['order_date']; ?></td>
                    <td class="text-center align-middle">
                        <?php 
                        foreach ($customers as $customer) {
                            if ($order['cus_id'] == $customer['cus_id']) {
                                echo $customer['cus_name'];
                                break; // Exit the loop once the matching book is found
                            }
                        }?>
                    </td>
                    <td class="text-center align-middle"><?php echo $order['payment_method']; ?></td>
                    <td class="text-center align-middle"><?php echo $order['invoice_method']; ?></td>
                    <td class="text-center align-middle"><?php echo $order['order_address']; ?></td>
                    <td class="text-center align-middle">$<?php echo $order['order_total_price']; ?></td>
                    <td class="text-center align-middle"><button onclick="showText(<?php echo $order['order_id']; ?>)" data-bs-toggle="modal" data-bs-target="#orderModal">點我看更多</button></td>
                    <td class="text-center align-middle"><button class="finished-button" onclick="finished(<?=$order['order_id']?>)">處理</button></td>
                </tr>
            <?php 
            }?>
            <?php if($count == 0){
                echo "<tr><td colspan='9' style='text-align: center;'>沒有找到未處理的訂單</td></tr>";
            }?>
        </table>
        <div class="modal fade" id="orderModal" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true"style="width:100%;">
            <div class="modal-dialog modal-dialog-centered" >
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="orderModalLabel">訂單詳細資訊</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" style="white-space: pre-wrap;">
                        <!-- 在這裡放置訂單詳細資訊的內容 -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">關閉</button>
                    </div>
                </div>
            </div>
        </div>
        <script>
            function showText(orderId) {
            var xhr = new XMLHttpRequest();
            var url = 'order_cart.php';
            xhr.open('POST', url, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                    var response = xhr.responseText;

                    // Get the modal body element
                    var modalBody = document.querySelector('.modal-body');

                    // Check if the response is empty
                    if (response.trim() === '') {
                        modalBody.textContent = "無法取得訂單詳細資訊！";
                    } else {
                        // Set the response as the content of the modal body
                        modalBody.textContent = response;
                    }

                    // Show the modal
                    var modal = new bootstrap.Modal(document.getElementById('orderModal'));
                    modal.show();

                    // Enable the page interaction
                    document.body.classList.add('modal-open');

                    // Add an event listener to the modal close button
                    var closeButton = document.querySelector('.btn-secondary[data-bs-dismiss="modal"]');
                    closeButton.addEventListener('click', function() {
                        modal.hide();

                        // Disable the modal backdrop and restore page interaction
                        var backdrop = document.querySelector('.modal-backdrop');
                        backdrop.parentNode.removeChild(backdrop);
                        document.body.classList.remove('modal-open');
                    });

                    // Add an event listener to the modal dismiss button (close button on the top-right corner)
                    var dismissButton = document.querySelector('.modal-header .btn-close[data-bs-dismiss="modal"]');
                    dismissButton.addEventListener('click', function() {
                        modal.hide();

                        // Disable the modal backdrop and restore page interaction
                        var backdrop = document.querySelector('.modal-backdrop');
                        backdrop.parentNode.removeChild(backdrop);
                        document.body.classList.remove('modal-open');
                    });
                }
            };
            xhr.send('orderId=' + orderId);
        }
        </script>
        <script>
            function finished(orderId) {
                var confirmed = confirm('確認處理該訂單嗎?');
                if (confirmed) {
                    var xhr = new XMLHttpRequest();
                    var url = 'order_finished.php'; // remove_cart_item.php 的 URL
                    xhr.open('POST', url, true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

                    // 處理AJAX回應
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                            // 處理後端回應
                            var response = xhr.responseText;
                            alert(response); // 可以在這裡顯示成功訊息或進行其他操作
                            // 刷新页面
                            window.location.reload();
                        }
                    };

                    // 发送 AJAX 请求，将 cartId 发送到后端进行删除操作
                    xhr.send('orderId=' + orderId);
                }
                else{
                    alert('取消處理');
                }
            }
        </script>
        <br/>
        <h1 class="centered-heading">本日已處理的訂單</h1>
        <table class="table">
            <tr>
                <th class="text-center">項次</th>
                <th class="text-center">時間</th>
                <th class="text-center">顧客</th>
                <th class="text-center">金額</th>
            </tr>
            <?php $count = 0;
            foreach($orders2 as $order){
                $count++;?>
                <tr>
                    <td class="text-center">
                        <div class="bg-gray-100"><?php echo $count; ?></div>
                    </td>
                    <td class="text-center"><?php echo $order['order_date']; ?></td>
                    <td class="text-center">
                        <?php 
                        foreach ($customers as $customer) {
                            if ($order['cus_id'] == $customer['cus_id']) {
                                echo $customer['cus_name'];
                                break; // Exit the loop once the matching book is found
                            }
                        }?>
                    </td>
                    <td class="text-center">$<?php echo $order['order_total_price']; ?></td>
            <?php 
            }?>
            <?php if($count == 0){
                echo "<tr><td colspan='5' style='text-align: center;'>沒有找到今天處理的訂單</td></tr>";
            }?>
        </table>
    </div>
</body>

</html>
