<?php
session_start();

// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

// 建立資料庫連線
$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連線是否成功
if ($conn->connect_error) {
    die("資料庫連線失敗: " . $conn->connect_error);
}

// 預設沒有錯誤訊息
$errors = [];
//新增book
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['book_submit'])) {
    $isbn = $_POST['ISBN'];
    $booktitle = $_POST['book_title'];
    $author = $_POST['book_author'];
    $yearofpub = $_POST['year_of_publication'];
    $publisher = $_POST['book_publisher'];
    $image = $_POST['Image'];
    $bookprice = $_POST['book_price'];
    $bookpricevip = round($bookprice * 0.9, 2);
    $category = $_POST['book_category'];
    $cover = $_POST['book_cover'];


    //檢查book_id是否重複
    $sql = "SELECT * FROM bookstore WHERE book_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $bookid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "book_id已被使用，請選擇其他編號";
    }

    //檢查ISBN是否重複
    $sql = "SELECT * FROM bookstore WHERE ISBN = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $isbn);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "ISBN已被使用，請重新輸入";
    }

    //檢查image格式
    if (!filter_var($image, FILTER_VALIDATE_URL)) {
        $errors[] = "書本圖片URL格式無效";
    }

    //檢查price形式
    if (!preg_match("/^\d+(\.\d{2})?$/", $bookprice)) {
        $errors[] = "價格格式無效，請輸入有效的價格";
    }

    if (empty($errors)) {
        $sql = "INSERT INTO bookstore (ISBN, book_title, book_author, year_of_publication, book_publisher, `Image`, manager_id, book_price, book_price_vip, book_inventory, book_category, book_cover)
		VALUES ('$isbn', '$booktitle', '$author', '$yearofpub', '$publisher', '$image', 1, '$bookprice', '$bookpricevip', 50, '$category', '$cover')";
        if ($conn->query($sql) === TRUE) {

            header("Location: add.php?book_success=新增成功");
            exit();
        } else {
            echo "新增失敗: " . $conn->error;
        }
    } else {
        $error_message = implode("<br>", $errors);
        if (isset($_POST['book_submit'])) { 
            header("Location: add.php?book_error=$error_message"); 
        } else if (isset($_POST['coupon_submit'])) { 
            header("Location: add.php?coupon_error=$error_message"); 
        }
        exit();
    }
}
//新增coupon
if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['coupon_submit'])){
    $coupon_name = $_POST['coupon_name'];
    $coupon_discount = $_POST['coupon_discount'];
    
    //檢查coupon_name是否重複
    $sql = "SELECT * FROM coupon WHERE coupon_name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $coupon_name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "coupon_name已被使用，請重新輸入";
    }

    //檢查discount形式
    if (!preg_match("/^\d+(\.\d{2})?$/", $coupon_discount)) {
        $errors[] = "折抵格式無效，請輸入有效的折抵";
    }

    if (empty($errors)) {
        $sql2 = "INSERT INTO coupon(coupon_name, coupon_discount) VALUES ('$coupon_name', '$coupon_discount')";
        if ($conn->query($sql2) === TRUE) {

            header("Location: add.php?coupon_success=新增成功");
            exit();
        } else {
            echo "新增失敗: " . $conn->error;
        }
    } else {
        $error_message = implode("<br>", $errors);
        if (isset($_POST['book_submit'])) { 
            header("Location: add.php?book_error=$error_message"); 
        } else if (isset($_POST['coupon_submit'])) { 
            header("Location: add.php?coupon_error=$error_message"); 
        }
        exit();
    }
}
//刪除coupon
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['coupon_delete_submit'])) {
    $coupon_name = $_POST['coupon_name'];
    $stmt = $conn->prepare("SELECT coupon_id FROM coupon WHERE coupon_name = ?");
    $stmt->bind_param("s", $coupon_name);
    $stmt->execute();
    $result = $stmt->get_result();

    // 檢查是否獲取到結果
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $coupon_id = $row["coupon_id"];
    } else {
        echo "找不到相應的coupon_id";
        exit;
    }

    // 關閉預處理語句
    $stmt->close();
    if (empty($errors)) {
        $sqlDeleteOrder = "DELETE FROM orders WHERE coupon_id = '$coupon_id'";
        if($conn->query($sqlDeleteOrder) === FALSE){
            echo "Error Deleting orders record:".$conn->error; 
            exit;
        }
        $sql2 = "DELETE FROM coupon WHERE coupon_name = '$coupon_name'";
        if ($conn->query($sql2) === TRUE) {

            header("Location: add.php?coupon_delete_success=刪除成功");
            exit();
        } else {
            echo "刪除失敗: " . $conn->error;
        }
    } else {
        $error_message = implode("<br>", $errors);
        if (isset($_POST['book_delete_submit'])) { 
            header("Location: add.php?book_delete_error=$error_message"); 
        } else if (isset($_POST['coupon_delete_submit'])) { 
            header("Location: add.php?coupon_delete_error=$error_message"); 
        } 
        exit();
    }
}
//刪除book
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['book_delete_submit'])) {
    $isbn = $_POST['ISBN'];
    $booktitle = $_POST['book_title'];

    //檢查ISBN是否重複
    $sql = "SELECT * FROM bookstore WHERE ISBN = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $isbn);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        $errors[] = "沒有你輸入ISBN請重新輸入";
    }else{
        $sqlbooktitle = "SELECT book_title FROM bookstore WHERE ISBN = ?";
        $stmt = $conn->prepare($sqlbooktitle);
        $stmt->bind_param("s", $isbn);
        $stmt->execute();
        $stmt->bind_result($db_booktitle);
        $stmt->fetch();
        $stmt->close();

        if ($booktitle != $db_booktitle) {
            $errors[] = "輸入的書名與ISBN不相符，請重新輸入";
        }
    }
    

    if (empty($errors)) {
        // 使用預處理語句獲取book_id值
        $stmt = $conn->prepare("SELECT book_id FROM bookstore WHERE book_title = ? AND ISBN = ?");
        $stmt->bind_param("ss", $booktitle, $isbn);
        $stmt->execute();
        $result = $stmt->get_result();
        
        // 檢查是否獲取到結果
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $bookid = $row["book_id"];
        }
        // } else {
        //     echo "找不到相應的book_id";
        //     exit;
        // }
    
        // 關閉預處理語句
        $stmt->close();
            $sqlDeletecart = "DELETE FROM cart WHERE book_id = $bookid";
            if($conn->query($sqlDeletecart) === false){
                echo "Error Deleting cart record:".$conn->error; 
                exit;
            }
        $sql2 = "DELETE FROM bookstore WHERE book_title = '$booktitle' AND ISBN = '$isbn'";
        if ($conn->query($sql2) === TRUE) {

            header("Location: add.php?book_delete_success=刪除成功");
            exit();
        } else {
            echo "刪除失敗: " . $conn->error;
        }
    } else {
        $error_message = implode("<br>", $errors);
        if (isset($_POST['book_delete_submit'])) { 
            header("Location: add.php?book_delete_error=$error_message"); 
        } else if (isset($_POST['coupon_delete_submit'])) { 
            header("Location: add.php?coupon_delete_error=$error_message"); 
        } 
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager</title>

    <!-- bootstrap 5 CDN-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
        crossorigin="anonymous"></script>
    <style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
    </style>
</head>

<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
                <a class="navbar-brand" href="admin.php" style="margin-right: 100px;">林宜叡的家</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link active" aria-current="page" href="add.php">Add</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="order.php">Order</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="inventory.php">Inventory</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="customer_manage.php">Member</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="logout_admin.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div style="display: flex; justify-content: space-between; text-align: center;">
            <div style="flex-basis: 50%; ">
                <form action="add.php" method="post" enctype="multipart/form-data"
                    class="shadow p-4 rounded mt-5" style="width: 90%; max-width: 50rem;">

                <h1 class="text-center pb-5 display-4 fs-3">
                    加入書籍
                </h1>
                <?php if (isset($_GET['book_error'])) { ?>
                <div class="alert alert-danger" role="alert">
                    <?= ($_GET['book_error']); ?>
                </div>
                <?php } ?>
                <?php if (isset($_GET['book_success'])) { ?>
                <div class="alert alert-success" role="alert">
                    <?= htmlspecialchars($_GET['book_success']); ?>
                </div>
                <?php } ?>
                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label">
                        ISBN
                    </label>
                    <input type="text" class="form-control" value="<?=$desc?>" name="ISBN" id="ISBN">
                </div>

                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label">
                        Book Title
                    </label>
                    <input type="text" class="form-control" value="<?=$desc?>" name="book_title" id="book_title">
                </div>

                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label">
                        Book Author
                    </label>
                    <input type="text" class="form-control" value="<?=$desc?>" name="book_author" id="book_author">
                </div>

                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label">
                        Public Year
                    </label>
                    <input type="text" class="form-control" value="<?=$desc?>" name="year_of_publication"
                        id="year_of_publication">
                </div>

                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label">
                        Book Publisher
                    </label>
                    <input type="text" class="form-control" value="<?=$desc?>" name="book_publisher" id="book_publisher">
                </div>

                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label">
                        Book Image
                    </label>
                    <input type="text" class="form-control" value="<?=$desc?>" name="Image" id="Image">
                </div>

                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label">
                        Book Price
                    </label>
                    <input type="text" class="form-control" value="<?=$desc?>" name="book_price" id="book_price">
                </div>
                    
                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label">
                        Book Category
                    </label>
                    <select name="book_category" class="form-control" id="book_category">
                        <option value="Fiction">Fiction</option>
                        <option value="History">History</option>
                        <option value="Romance">Romance</option>
                        <option value="Mystery">Mystery</option>
                        <option value="Thriller">Thriller</option>
                    </select>
                </div>

                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label">
                        Book Cover
                    </label>
                    <select name="book_cover" class="form-control" id="book_cover">
                        <option value="Hardcover">Hardcover</option>
                        <option value="Paperback">Paperback</option>
                    </select>
                </div>
                <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-primary" name="book_submit">Add Book</button>
                </div>
                </form>
            </div>
            <div style="flex-basis: 50%;">
                <form action="add.php" method="post" enctype="multipart/form-data"
                    class="shadow p-4 rounded mt-5" style="width: 90%; max-width: 50rem;">

                    <h1 class="text-center pb-5 display-4 fs-3">
                        刪除書籍
                    </h1>
                    <?php if (isset($_GET['book_delete_error'])) { ?>
                    <div class="alert alert-danger" role="alert">
                        <?= ($_GET['book_delete_error']); ?>
                    </div>
                    <?php } ?>
                    <?php if (isset($_GET['book_delete_success'])) { ?>
                    <div class="alert alert-success" role="alert">
                        <?= htmlspecialchars($_GET['book_delete_success']); ?>
                    </div>
                    <?php } ?>
                    
                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label" >
                        ISBN
                    </label>
                    <input type="text" class="form-control" value="<?=$desc?>" name="ISBN" id="ISBN">
                </div>

                <div class="mb-3"  style="text-align: center;">
                    <label class="form-label">
                        Book Title
                    </label>
                    <input type="text" class="form-control" value="<?=$desc?>" name="book_title" id="book_title">
                </div>
                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-primary" name="book_delete_submit">Delete Book</button>
                </div>
                </form>
            </div>
            <div style="flex-basis: 50%;">
                <form action="add.php" method="post" enctype="multipart/form-data"
                    class="shadow p-4 rounded mt-5" style="width: 90%; max-width: 50rem;">

                    <h1 class="text-center pb-5 display-4 fs-3">
                        加入優惠券
                    </h1>
                    <?php if (isset($_GET['coupon_error'])) { ?>
                    <div class="alert alert-danger" role="alert">
                        <?= ($_GET['coupon_error']); ?>
                    </div>
                    <?php } ?>
                    <?php if (isset($_GET['coupon_success'])) { ?>
                    <div class="alert alert-success" role="alert">
                        <?= htmlspecialchars($_GET['coupon_success']); ?>
                    </div>
                    <?php } ?>
                    
                    <div class="mb-3"  style="text-align: center;">
                        <label class="form-label">
                            Coupon Name
                        </label>
                        <input type="text" class="form-control" value="<?=$title?>" name="coupon_name" id="coupon_name">
                    </div>
                    <div class="mb-3"  style="text-align: center;">
                        <label class="form-label">
                            Coupon_Discount
                        </label>
                        <input type="text" class="form-control" value="<?=$title?>" name="coupon_discount" id="coupon_discount">
                    </div>
                    <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-primary" name="coupon_submit">Add Coupon</button>
                    </div>
                </form>
            </div>
            <div style="flex-basis: 50%;">
                <form action="add.php" method="post" enctype="multipart/form-data"
                    class="shadow p-4 rounded mt-5" style="width: 90%; max-width: 50rem;">

                    <h1 class="text-center pb-5 display-4 fs-3">
                        刪除優惠券
                    </h1>
                    <?php if (isset($_GET['coupon_delete_error'])) { ?>
                    <div class="alert alert-danger" role="alert">
                        <?= ($_GET['coupon_delete_error']); ?>
                    </div>
                    <?php } ?>
                    <?php if (isset($_GET['coupon_delete_success'])) { ?>
                    <div class="alert alert-success" role="alert">
                        <?= htmlspecialchars($_GET['coupon_delete_success']); ?>
                    </div>
                    <?php } ?>
                    
                    <div class="mb-3"  style="text-align: center;">
                        <label class="form-label" >
                            Coupon Name
                        </label>
                        <select class="form-select" name="coupon_name" id="coupon_name" >
                            <?php
                                $sql3 = "SELECT coupon_name FROM coupon";
                                $result = $conn->query($sql3);
            
                                // 生成選項
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $coupon_name = $row["coupon_name"];
                                        echo "<option value=\"$coupon_name\">$coupon_name</option>";
                                    }
                                }
            
                                // 關閉資料庫連接
                                $conn->close();
                            ?>
                        </select>
                    </div>
                    <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-primary" name="coupon_delete_submit">Delete Coupon</button>
                    </div>
                </form>
            </div>
        </div>    
    </div>
</body>
</html>
