<?php 
session_start();
# Database Connection File
include "db_conn.php";
$member_account = $_SESSION['user'];
# Get member information
$sql  = "SELECT * FROM customer WHERE cus_account=?";
$stmt = $conn->prepare($sql);
$stmt->execute([$member_account]);
 
if ($stmt->rowCount() > 0) {
    $current_member = $stmt->fetch();
}else {
    $current_member = 0;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Book Store</title>

    <!-- bootstrap 5 CDN-->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    <style>
	.gray-background {
		background-color: #f2f2f2;
	}
    </style>
	<style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
    .container2 {
        display: flex;
    }

    .sidebar {
        margin-left: 0px;
        width: 150px;
        background-color: #f2f2f2;
        padding: 20px;
        height: 605px;
    }

    .sidebar a {
        display: block;
        font-size: 18px;
        margin-bottom: 10px;
        text-decoration: none;
        color: #333;
    }

    .content {
        flex-grow: 1;
        padding-left: 20px;
        padding-top: 10px;
        /* padding:10px; */
        background-color: #fff;
    }

    .hidden {
        display: none;
    }
    </style>
    <script>
        function showContent(contentId) {
            // 隱藏所有內容
            var contents = document.getElementsByClassName('content');
            for (var i = 0; i < contents.length; i++) {
                contents[i].classList.add('hidden');
            }

            // 顯示選定的內容
            var content = document.getElementById(contentId);
            content.classList.remove('hidden');
        }
    </script>
</head>
<body>
	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-light" style="position:fixed; z-index:999">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="<?php echo isset($_SESSION['user']) ? 'member.php' : 'index.php'; ?>" style="margin-right: 100px;">林董的線上書店</a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" 
		         id="navbarSupportedContent">
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="<?php echo isset($_SESSION['user']) ? 'member.php' : 'index.php'; ?>">Store</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="contact.php">Contact</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link active" 
                    aria-current="page" 
		             href="about.php">About</a>
		        </li>
		        <li class="nav-item dropdown" style="margin-right: 10px;">
					<?php if (isset($_SESSION['user'])){?>
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="img/unnamed.jpg" alt="User" class="user-icon" style="max-width: 40px; border-radius: 50%; margin-top:-5px;">
                        <span class="user-name"><?=$current_member['cus_name']?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
					<li style="text-align: center;"><a class="dropdown-item" href="cart.php">購物車</a></li>
						<li><hr class="dropdown-divider"></li>
						<li  style="text-align: center;"><a class="dropdown-item" href="edit.php">編輯個資</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li  style="text-align: center;"><a class="dropdown-item" href="logout.php">登出</a></li>
                    </ul>
					<?php }else{?>
					<a class="nav-link" 
		            href="login.php">Login</a>
		          <?php } ?>
                </li>
				<?php if (isset($_SESSION['user'])){?>
				<li>
					<a href="cart.php">
					<img src="img/cart.png" style="max-width: 40px; border-radius: 0%; margin-top: 10px;" >
					</a>
				</li>
                <?php } ?>
		      </ul>
		    </div>
		  </div>
		</nav>
	</div>
    <br>
    <div class="container"style="margin-top:100px;">
    <h2>關於我們</h2>
    </div>
    <br>
    <div class="container container2">
        <div class="sidebar">
            <a href="#" onclick="showContent('company-philosophy')">公司簡介</a>
            <a href="#" onclick="showContent('mission')">公司理念</a>
            <a href="#" onclick="showContent('affiliated-companies')">關係企業</a>
            <a href="#" onclick="showContent('responsibility')">社會責任</a>
        </div>
        <div class="content" id="company-philosophy">
            <h3>公司簡介</h3>
            <p>本書店創立於2023年，創辦人林董因於情場失利，憤而抄起書本狂念。<br>在書海中尋求解脫，最終將一切看淡，感情猶如浮雲。<br>為解救相同境遇或仍在情場中漂泊的人們，故創立此書店。</p>
            <img src="img/a.png">
        </div>
        <div class="content hidden" id="mission">
            <h3>公司理念</h3>
            <p>本書店僅提供英文書籍，因林董本人於大三修習工程經濟時，期中與期末帶著英漢字典應試，<br>覺得真的很重，深感英文之重要性，故僅提供英文書籍，希望所有客戶能夠提升英文能力。</p>
        </div>
        <div class="content hidden" id="affiliated-companies">
            <h3>關係企業</h3>
            <p>本公司之關係企業為<a href = "https://www.centerlab.com.tw/industrial/company/19">得益生技</a>，which is 林董父親之公司。</p>
        </div>
        <div class="content hidden" id="responsibility">
            <h3>社會責任</h3>
            <p>本公司以社會責任為己任，造福人群捨我其誰，凡是於情場失利者，購書皆有優惠。</p>
        </div>
    </div>
</body>
</html>