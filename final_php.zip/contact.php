<?php 
session_start();
# Database Connection File
include "db_conn.php";
$member_account = $_SESSION['user'];
# Get member information
$sql  = "SELECT * FROM customer WHERE cus_account=?";
$stmt = $conn->prepare($sql);
$stmt->execute([$member_account]);
 
if ($stmt->rowCount() > 0) {
    $current_member = $stmt->fetch();
}else {
    $current_member = 0;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Book Store</title>

    <!-- bootstrap 5 CDN-->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    <style>
	.gray-background {
		background-color: #f2f2f2;
	}
    </style>
	<style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
    h2 {
        text-align: center;
    }
    .contact-info {
        margin-bottom: 20px;
    }
    .contact-info label {
        display: inline-block;
        width: 120px;
        font-weight: bold;
    }
    .contact-info span {
        display: inline-block;
        width: 250px;
    }
    .contact-info a {
        text-decoration: none;
    }
    .cu-linkbrick {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
    }
    .col-md-4 {
        flex: 0 0 33.33%;
        max-width: 33.33%;
    }
    .pic {
        text-align: center;
    }
    .pic img {
        max-width: 100%;
        height: auto;
    }
    .pt-5 {
        padding-top: 5px;
    }
    .thsr-h3, .h3 {
        font-size: 1.5rem;
        font-weight: bold;
        text-align: center;
        margin-bottom: 10px;
    }
    .gray {
        color: #888;
    }
    .text-center {
        text-align: center;
    }
    .block {
        display: block;
    }
    .mb-10 {
        margin-bottom: 10px;
    }
    .mt-10 {
        margin-top: 10px;
    }
    .darkgray {
        color: #444;
    }
    .font-bold {
        font-weight: bold;
    }
    .phone-b {
        display: block;
        margin-bottom: 0;
    }
    .mail{
        display: block;
        text-align: center;
        margin-bottom: 10px;
    }  
    </style>
    <script>
        function showContent(contentId) {
            // 隱藏所有內容
            var contents = document.getElementsByClassName('content');
            for (var i = 0; i < contents.length; i++) {
                contents[i].classList.add('hidden');
            }

            // 顯示選定的內容
            var content = document.getElementById(contentId);
            content.classList.remove('hidden');
        }
    </script>
</head>
<body>
	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-light" style="position:fixed; z-index:999">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="<?php echo isset($_SESSION['user']) ? 'member.php' : 'index.php'; ?>" style="margin-right: 100px;">林董的線上書店</a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" 
		         id="navbarSupportedContent">
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="<?php echo isset($_SESSION['user']) ? 'member.php' : 'index.php'; ?>">Store</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link active" 
                        aria-current="page" 
		             href="contact.php">Contact</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="about.php">About</a>
		        </li>
		        <li class="nav-item dropdown" style="margin-right: 10px;">
					<?php if (isset($_SESSION['user'])){?>
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="img/unnamed.jpg" alt="User" class="user-icon" style="max-width: 40px; border-radius: 50%; margin-top:-5px;">
                        <span class="user-name"><?=$current_member['cus_name']?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
					<li style="text-align: center;"><a class="dropdown-item" href="cart.php">購物車</a></li>
						<li><hr class="dropdown-divider"></li>
						<li  style="text-align: center;"><a class="dropdown-item" href="edit.php">編輯個資</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li  style="text-align: center;"><a class="dropdown-item" href="logout.php">登出</a></li>
                    </ul>
					<?php }else{?>
					<a class="nav-link" 
		            href="login.php">Login</a>
		          <?php } ?>
                </li>
				<?php if (isset($_SESSION['user'])){?>
				<li>
					<a href="cart.php">
					<img src="img/cart.png" style="max-width: 40px; border-radius: 0%; margin-top: 10px;" >
					</a>
				</li>
                <?php } ?>
		      </ul>
		    </div>
		  </div>
		</nav>
	</div>
    <br>
    <div style="margin-top:100px;">
    <h2 style= "font-weight:bold;">聯絡我們</h2>
    </div>
    <hr>
    <div class="cu-linkbrick row accordion">
        <div class="col-md-4 col-12">
            <div class="pt-5 thsr-h3 h3">電子信箱</div>
            <span class="darkgray font-bold  mail">lindon@mail.com</span>
            <p class="gray text-center">請將您的寶貴意見以填寫表單方式送出<br>我們將於工作日由專人以郵件回覆您的問題</p>
            </a>
        </div>
        <div class="col-md-4 col-12">    
            <div class="pt-5 thsr-h3 h3">線上客服</div>
            <div class="gray text-center">
                <p class="block mb-10 mt-10">提供即時的個人服務，包括訂單查詢、退換貨申請等業務</p>
                <p class="block mb-10 mt-10">
                        客服專員上班時間：<br>
                        週一至週五 AM 9:00 ~ PM 6:00
                </p>
                </div>
            </a>
        </div>
        <div class="col-md-4 col-12">
            <div class="culink">
                <div class="pt-5 thsr-h3 h3">客服專線</div>
                <div class="gray text-center">
                    <span class="darkgray font-bold  phone-b">02-54875487</span>
                    <p class="block mb-10 mt-10">服務時間：<br> 每日AM 9:00 ~ PM 6:00</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>