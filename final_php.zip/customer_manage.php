<?php
session_start();

// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

include "db_conn.php";


$sql  = "SELECT * FROM bookstore ORDER bY book_id DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $books = $stmt->fetchAll();
}else {
   $books = 0;
}

$sql  = "SELECT * FROM cart where cart_status = 'finished' AND cus_id = ? ORDER bY cart_id";
$stmt = $conn->prepare($sql);
$stmt->execute([$_GET['nnn']]);
if ($stmt->rowCount() > 0) {
    $cart_items2 = $stmt->fetchAll();
}else {
	$cart_items2 = 0;
}

# Get all Orders function
$sql  = "SELECT * FROM orders where order_status = 'finished'ORDER bY order_id";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $orderitems = $stmt->fetchAll();
}else {
	$orderitems = 0;
}

$sql  = "SELECT * FROM orders where order_status = 'finished' AND cus_id = ? ORDER bY order_id";
$stmt = $conn->prepare($sql);
$stmt->execute([$_GET['nnn']]);
if ($stmt->rowCount() > 0) {
    $orderitems3 = $stmt->fetchAll();
}else {
	$orderitems3 = 0;
}
$conn = new mysqli($servername, $username, $password, $dbname);

if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['cus_submit'])){
    $cus = $_POST['cus'];
    
    //檢查coupon_name是否重複
    $sql = "SELECT * FROM customer WHERE cus_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cus);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 0) {
        $errors[] = "你輸入的顧客未存在";
    }
    if (empty($errors)) {
        $nnn = $cus;
        header("Location: customer_manage.php?cus_success=新增成功&nnn=" . urlencode($nnn));
        exit();
    }else{
        $error_message = implode("<br>", $errors);
        if(isset($_POST['cus_submit'])){
            header("Location: customer_manage.php?cus_error=$error_message");
        }
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- bootstrap 5 CDN-->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    <title>Customer Management</title>
    <style>
        table {
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
        }

        th {
            font-weight: bold;
            background-color: lightgray;
        }

        .delete-button {
            background-color: navy;
            color: white;
            font-weight: bold;
            border: 1px solid black;
            padding: 5px 10px;
            cursor: pointer;
        }

        .upgrade-button {
            background-color: gold;
            color: black;
            font-weight: bold;
            border: 1px solid black;
            padding: 5px 10px;
            cursor: pointer;
        }
        .centered-heading {
		text-align: center;
	    }
        .centered-container {
            text-align: center;
        }
        .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
        }
        
        .navbar-brand {
            font-size: 40px; /* 调整导航品牌的字体大小 */
        }
        
        .navbar-nav .nav-link {
            font-size: 28px; /* 调整导航链接的字体大小 */
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <a class="navbar-brand" href="admin.php" style="margin-right: 100px;">林宜叡的家</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                        aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item" style="margin-right: 100px;">
                                <a class="nav-link" href="add.php">Add</a>
                            </li>
                            <li class="nav-item" style="margin-right: 100px;">
                                <a class="nav-link" href="order.php">Order</a>
                            </li>
                            <li class="nav-item" style="margin-right: 100px;">
                                <a class="nav-link" href="inventory.php">Inventory</a>
                            </li>
                            <li class="nav-item" style="margin-right: 100px;">
                                <a class="nav-link active" aria-current="page" href="customer_manage.php">Member</a>
                            </li>
                            <li class="nav-item" style="margin-right: 100px;">
                                <a class="nav-link" href="logout_admin.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav><br>
        <h1  class="centered-heading">可升級至VIP之會員</h4>
        <div style="display: flex; justify-content: center; align-items: center;">
        <table  class="centered-heading">
            <tr>
                <th class="text-center" style="width: 50px;">編號</th>
                <th class="text-center" style="width: 150px;">姓名</th>
                <th class="text-center" style="width: 200px;">電話</th>
                <th class="text-center" style="width: 200px;">郵件</th>
                <th class="text-center" style="width: 150px;">帳號</th>
                <th class="text-center" style="width: 150px;">消費</th>
                <th class="text-center" style="width: 150px;">管理</th>
            </tr>

            <?php
            // 建立與資料庫的連接
            $conn = new mysqli($servername, $username, $password, $dbname);

            // 檢查連接是否成功
            if ($conn->connect_error) {
                die("連接資料庫失敗: " . $conn->connect_error);
            }

            // 查詢滿足條件的 customer 資料
            $sql1 = "SELECT * FROM customer WHERE cus_total_purchase > 50 AND cus_vip_state = 0";  
            $result1 = $conn->query($sql1);

            // 顯示符合條件的 customer 資料
            if ($result1->num_rows > 0) {
                while ($row = $result1->fetch_assoc()) {
                    echo "<tr>";
                    echo '<td class="text-center">' . $row["cus_id"] . "</td>";
                    echo '<td class="text-center">' . $row["cus_name"] . "</td>";
                    echo '<td class="text-center">' . $row["cus_phone_num"] . "</td>";
                    echo '<td class="text-center">' . $row["cus_email"] . "</td>";
                    echo '<td class="text-center">' . $row["cus_account"] . "</td>";
                    echo '<td class="text-center">' . '$' . $row["cus_total_purchase"] . "</td>";
                    echo '<td><button class="upgrade-button" onclick="upgradeToVIP(' . $row["cus_id"] . ')">升級</button></td>';
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='10'>沒有找到符合條件的 customer 資料</td></tr>";
            }
            ?>
        </table>
        </div><br>
        <hr>
        <h1 class="centered-heading">VIP會員</h4>
        <div style="display: flex; justify-content: center; align-items: center;">
        <table class="centered-heading">
            <tr>
                <th class="text-center" style="width: 50px;">編號</th>
                <th class="text-center" style="width: 150px;">姓名</th>
                <th class="text-center" style="width: 200px;">電話</th>
                <th class="text-center" style="width: 200px;">郵件</th>
                <th class="text-center" style="width: 150px;">帳號</th>
                <th class="text-center" style="width: 150px;">消費</th>
                <th class="text-center" style="width: 150px;">管理</th>
            </tr>
            <?php
            // 查詢 customer 資料
            $sql2 = "SELECT * FROM customer WHERE cus_vip_state = 1";
            $result2 = $conn->query($sql2);

            // 顯示 customer 資料
            if ($result2->num_rows > 0) {
                while ($row = $result2->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["cus_id"] . "</td>";
                    echo "<td>" . $row["cus_name"] . "</td>";
                    echo "<td>" . $row["cus_phone_num"] . "</td>";
                    echo "<td>" . $row["cus_email"] . "</td>";
                    echo "<td>" . $row["cus_account"] . "</td>";
                    echo "<td>" . '$' . $row["cus_total_purchase"] . "</td>";
                    echo '<td><button class="delete-button" onclick="deleteCustomer(' . $row["cus_id"] . ')">刪除</button></td>';
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='10'>沒有找到任何 customer 資料</td></tr>";
            }
            ?>

        </table>
        </div>
        <hr>
        <h1 class="centered-heading">普通會員</h4>
        <div style="display: flex; justify-content: center; align-items: center;">
        <table class="centered-heading">
            <tr>
                <th class="text-center" style="width: 50px;">編號</th>
                <th class="text-center" style="width: 150px;">姓名</th>
                <th class="text-center" style="width: 200px;">電話</th>
                <th class="text-center" style="width: 200px;">郵件</th>
                <th class="text-center" style="width: 150px;">帳號</th>
                <th class="text-center" style="width: 150px;">消費</th>
                <th class="text-center" style="width: 150px;">管理</th>
            </tr>
            <?php
            // 查詢 customer 資料
            $sql = "SELECT * FROM customer WHERE cus_vip_state = 0";
            $result = $conn->query($sql);

            // 顯示 customer 資料
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["cus_id"] . "</td>";
                    echo "<td>" . $row["cus_name"] . "</td>";
                    echo "<td>" . $row["cus_phone_num"] . "</td>";
                    echo "<td>" . $row["cus_email"] . "</td>";
                    echo "<td>" . $row["cus_account"] . "</td>";
                    echo "<td>" . '$' . $row["cus_total_purchase"] . "</td>";
                    echo '<td><button class="delete-button" onclick="deleteCustomer(' . $row["cus_id"] . ')">刪除</button></td>';
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='10'>沒有找到任何 customer 資料</td></tr>";
            }
            $conn->close();
            ?>

        </table>
    </div>
    <br/>
    <h1 class="centered-heading">顧客訂單</h1>
    <br/>
    <div style="display: flex; justify-content: center">
        <form action="customer_manage.php" method="POST"  style="font-size: 25px;">
            <label for="cus">顧客ID:</label>
            <input type="text" id="cus" name="cus" placeholder="輸入顧客ID" required>
            <button type="submit" name="cus_submit" class="btn btn-primary">提交</button>
        </form>
    </div>
    <?php if(isset($_GET['cus_error'])){?>
        <div class="alert alert-danger" role="alert" style="text-align: center;">
            <?= ($_GET['cus_error']); ?>
        </div>
    <?php
    }?> 
    <?php if(isset($_GET['cus_success'])){?>
        <div class="centered-container">
            <br/>
            <h3 class="centered-heading">顧客ID=<?=$_GET['nnn']?>的訂單</h1>
            <br/>
            <?php $count2 = 0;?>
            <?php foreach ($orderitems3 as $orderitem) {
                $count2++;
                ?>
                <div class="bg-purple-100">第<?php echo $count2; ?>筆<?php echo str_repeat('&nbsp;', 4); ?><?php echo $orderitem['order_date']; ?></div>
                <table class="table">
                    <thead>
                        <tr>
                            <th class="text-center">項次</th>
                            <th class="text-center" style="width: 500px;">書名</th>
                            <th class="text-center">單價</th>
                            <th class="text-center">數量</th>
                            <th class="text-center">小計</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $totalSum = 0; // Variable to store the total sum
                        $count = 0;
                        foreach ($cart_items2 as $item) {
                            if ($item['cus_id'] == $_GET['nnn'] && $item['order_id'] == $orderitem['order_id']) {
                                $subtotal = $item['unit_price'] * $item['cart_num']; // Calculate subtotal for each item
                                $totalSum += $subtotal; // Add the subtotal to the total sum
                                $count++;
                                ?>
                                <tr>
                                    <td class="text-center">
                                        <div class="bg-gray-100"><?php echo $count; ?></div>
                                    </td>
                                    <td class="text-center">
                                        <?php
                                        foreach ($books as $book) {
                                            if ($book['book_id'] == $item['book_id']) {
                                                echo $book['book_title'];
                                                break; // Exit the loop once the matching book is found
                                            }
                                        }
                                        ?>
                                    </td>
                                    <td class="text-center">$<?php echo $item['unit_price']; ?></td>
                                    <td class="text-center"><?php echo $item['cart_num']; ?></td>
                                    <td class="text-center">$<?php echo $subtotal; ?></td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4"></td> <!-- 前三个空单元格 -->
                            <?php $money=0;
                                if($orderitem['coupon_id']){
                                    foreach($coupons as $coupon){
                                        if($orderitem['coupon_id']==$coupon['coupon_id']){
                                            $money = $coupon['coupon_discount'];
                                        }
                                }
                            }?>
                            <td class="text-center">
                                <strong>
                                    總計：$<?php echo $totalSum; ?>
                                    <?php if($money!=0){?>
                                        <br/>
                                        折價後：$<?php echo $totalSum-$money;?>
                                    <?php }?>
                                </strong>
                            </td> <!-- 第四个单元格，向左对齐 -->
                        </tr>
                    </tfoot>
                </table>
            <?php
            }?>
        </div>
        <?php
    }?>

    <script>
        function upgradeToVIP(customerID) {
            if (confirm("確定要將該 customer 升級為 VIP 嗎？")) {
                // 使用 AJAX 向後端發送升級請求
                $.ajax({
                    url: "upgrade_to_vip.php",
                    type: "POST",
                    data: { id: customerID },
                    success: function (response) {
                        alert("已成功升級為 VIP");
                        location.reload(); // 重新載入頁面
                    },
                    error: function (xhr, status, error) {
                        console.log(xhr.responseText);
                    }
                });
            }
        }
    </script>

    <script>
        function deleteCustomer(customerID) {
            if (confirm("確定要刪除該 customer 的資料嗎？")) {
                // 使用 AJAX 向後端發送刪除請求
                var xhr = new XMLHttpRequest();
                var url = 'delete_cus.php'; // remove_cart_item.php 的 URL
                xhr.open('POST', url, true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

                // 處理AJAX回應
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                        // 處理後端回應
                        var response = xhr.responseText;
                        alert(response); // 可以在這裡顯示成功訊息或進行其他操作
                        // 刷新页面
                        window.location.reload();
                    }
                };

                // 发送 AJAX 请求，将 cartId 发送到后端进行删除操作
                    xhr.send('customerID=' + customerID);
            }
        }
    </script>
</body>
</html>
