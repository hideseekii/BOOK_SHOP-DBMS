<?php
date_default_timezone_set('Asia/Taipei');
session_start();

include "db_conn.php";

# Get all Order function
$today = date('Y-m-d');
$sql  = "SELECT * FROM orders where order_status='finished' AND DATE(order_date) = '$today'";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
	$orders = $stmt->fetchAll();
}else {
	$orders = 0;
}

$currentMonth = date('m');
$sql  = "SELECT * FROM orders where order_status='finished' AND MONTH(order_date) = '$currentMonth'";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
	$orders2 = $stmt->fetchAll();
}else {
	$orders2 = 0;
}

$sql  = "SELECT * FROM orders 
JOIN cart ON orders.order_id = cart.order_id 
WHERE orders.order_status = 'finished' 
AND MONTH(orders.order_date) = '$currentMonth'";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
	$carts = $stmt->fetchAll();
}else {
	$carts = 0;
}

$sql  = "SELECT * FROM orders 
JOIN cart ON orders.order_id = cart.order_id 
WHERE orders.order_status = 'finished' 
AND DATE(orders.order_date) = '$today'";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
	$carts2 = $stmt->fetchAll();
}else {
	$carts2 = 0;
}

$sql  = "SELECT * FROM bookstore";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
	$books = $stmt->fetchAll();
}else {
	$books = 0;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager</title>

    <!-- bootstrap 5 CDN-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
        crossorigin="anonymous"></script>
    <style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
    .centered-heading {
		text-align: center;
	}
    .bg-gray-100 {
    --tw-bg-opacity: 1;
    background-color: rgba(220, 221, 225, var(--tw-bg-opacity));
    }
    </style>
</head>

<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin.php" style="margin-right: 100px;">林宜叡的家</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link " href="add.php">Add</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="order.php">Order</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="inventory.php">Inventory</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="customer_manage.php">Member</a>
                        </li>
                        <li class="nav-item" style="margin-right: 100px;">
                            <a class="nav-link" href="logout_admin.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <br/>
        <h1 class="centered-heading"><?=$today?></h1>
        <br/>
        <div style="display: flex; justify-content: center; align-items: center;">
            <table class="table">
                <tr>
                    <th class="centered-heading"></th>
                    <th class="centered-heading" style="font-size: 50px;font-weight: bold;">營收</th>
                    <th class="centered-heading" style="font-size: 50px;font-weight: bold;">銷售量</th>
                </tr>
                <tr>
                    <td class="text-center" style="font-size: 50px;font-weight: bold;">本日</td>
                    <td>
                        <?php $money = 0;
                        foreach($orders as $order){
                            $money = $money + $order['order_total_price'];
                        }?>
                        <p class="centered-heading" style="font-size: 40px; color: red;">$<?= $money ?></p>
                    </td>
                    <td>
                        <?php $num=0;
                        foreach ($carts2 as $cart) {
                            $num = $num + $cart['cart_num'];
                        } ?>
                        <p class="centered-heading" style="font-size: 40px; color: red;"><?= $num ?>本</p>
                    </td>
                </tr>
                <tr>
                    <td class="text-center" style="font-size: 50px;font-weight: bold;" >本月</td>
                    <td>
                        <?php $money = 0;
                        foreach($orders2 as $order){
                            $money = $money + $order['order_total_price'];
                        }?>
                        <p class="centered-heading" style="font-size: 40px; color: red;">$<?= $money ?></p>
                    </td>
                    <td>
                        <?php $num=0;
                        foreach ($carts as $cart) {
                            $num = $num + $cart['cart_num'];
                        } ?>
                        <p class="centered-heading" style="font-size: 40px; color: red;"><?= $num ?>本</p>
                    </td>
                </tr>
            </table>
        </div>
        <br/>
        <h1 class="centered-heading">本月暢銷 TOP3</h1>
        <?php
            $bookCounts = array(); // 用於存放每本書的總數量
            foreach ($carts as $cart) {
                $bookId = $cart['book_id'];
                $cartNum = $cart['cart_num'];

                if (isset($bookCounts[$bookId])) {
                    $bookCounts[$bookId] += $cartNum; // 已存在該書籍的索引，將數量相加
                } else {
                    $bookCounts[$bookId] = $cartNum; // 新的書籍索引，設定初始數量
                }
            }
            $sortedBookCounts = $bookCounts; // 複製陣列以避免改變原始陣列
            arsort($sortedBookCounts); // 依照數量進行降冪排序
            $topThreeBooks = array_slice($sortedBookCounts, 0, 3, true); // 選取前三個元素
        ?>
        <div style="display: flex; justify-content: center; align-items: center;">
            <table class="table " style="font-size: 30px; width: 70%;">
                <thead>
                    <tr>
                        <th  class="text-center" style="width: 100px;">排名</th>
                        <th  class="text-center">書本</th>
                        <th  class="text-center" style="width: 100px;">數量</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $count = 0;
                    foreach ($topThreeBooks as $bookId => $totalNum) {
                        foreach ($books as $book) {
                            if ($book['book_id'] == $bookId) {
                                $bookTitle = $book['book_title'];
                                break;
                            }
                        }
                        $count++;
                        echo '<tr  class="text-center">';?>
                        <td class="text-center" >
                            <div class="bg-gray-100"><?php echo $count; ?></div>
                        </td>
                        <?php 
                        echo '<td  class="text-center">' . $bookTitle . "</td>";
                        echo '<td  class="text-center">' . $totalNum . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>
