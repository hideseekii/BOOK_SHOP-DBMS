<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$customerID = $_POST['customerID'];

// Delete associated records in the `cart` table
$sqlDeleteCart = "DELETE FROM cart WHERE cus_id = $customerID";
if ($conn->query($sqlDeleteCart) === false) {
    echo "Error deleting cart records: " . $conn->error;
    exit;
}

// Delete associated records in the `orders` table
$sqlDeleteOrders = "DELETE FROM orders WHERE cus_id = $customerID";
if ($conn->query($sqlDeleteOrders) === false) {
    echo "Error deleting orders records: " . $conn->error;
    exit;
}

// Delete the customer
$sqlDeleteCustomer = "DELETE FROM customer WHERE cus_id = $customerID";
if ($conn->query($sqlDeleteCustomer) === true) {
    echo "Success: Customer deleted";
} else {
    echo "Error deleting customer: " . $conn->error;
}

$conn->close();
?>
