<?php
session_start();

// 清除所有Session變數
session_unset();

// 結束Session
session_destroy();

// 導向登出頁面或其他適當的頁面
header("Location: login_admin.php");
exit();
?>
