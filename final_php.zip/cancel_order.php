<?php
// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the parameters from the AJAX request
$orderId = $_POST['orderId'];

$sql3 = "UPDATE cart 
        INNER JOIN bookstore ON cart.book_id = bookstore.book_id 
        SET cart.cart_status = 'finished', bookstore.book_inventory = bookstore.book_inventory + cart.cart_num
        WHERE cart.order_id = ?";
$stmt3 = $conn->prepare($sql3);
$stmt3->bind_param('i', $orderId);
$stmt3->execute();

$sql = "DELETE FROM cart WHERE order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $orderId);
if ($stmt->execute()) {
    $sql2 = "DELETE FROM orders WHERE order_id = ?";
    $stmt2 = $conn->prepare($sql2);
    $stmt2->bind_param('i', $orderId);
    if ($stmt2->execute()) {
        echo "移除成功";
    } else {
        echo "移除失败: " . $stmt2->error;
    }
} else {
    echo "移除失败: " . $stmt->error;
}


$stmt->close();
$stmt2->close();
$stmt3->close();
$conn->close();
?>