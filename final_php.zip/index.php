<?php 
session_start();

# Database Connection File
include "db_conn.php";

if (isset($_SESSION['user'])) {
    // 如果已經登入，可以執行一些相應的操作，例如重新導向至其他頁面
    header("Location: member.php");
    exit();
}
# Get All books function
$sql  = "SELECT * FROM bookstore ORDER by book_id DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
   	$books = $stmt->fetchAll();
}else {
    $books = 0;
}

# Get all Categories function
$sql  = "SELECT * FROM categories";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
	$categories = $stmt->fetchAll();
}else {
	$categories = 0;
}

# Get all Cover function
$sql  = "SELECT * FROM covers";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
	$covers = $stmt->fetchAll();
}else {
	$covers = 0;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Book Store</title>

    <!-- bootstrap 5 CDN-->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

	<style>
	.gray-background {
		background-color: #f2f2f2;
	}
    </style>
	<style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
	.back-to-top {

	display: none; /* 默認是隱藏的，這樣在第一屏才不顯示 */

	position: fixed; /* 位置是固定的 */

	bottom: 20px; /* 顯示在頁面底部 */

	right: 30px; /* 顯示在頁面的右邊 */

	z-index: 99; /* 確保不被其他功能覆蓋 */

	border: 1px solid #5cb85c; /* 顯示邊框 */

	outline: none; /* 不顯示外框 */

	background-color: #fff; /* 設置背景背景顏色 */

	color: #5cb85c; /* 設置文本顏色 */

	cursor: pointer; /* 滑鼠移到按鈕上顯示手型 */

	padding: 10px 15px 15px 15px; /* 增加一些內邊距 */

	border-radius: 10px; /* 增加圓角 */

	}

	.back-to-top:hover {

	background-color: #5cb85c; /* 滑鼠移上去時，反轉顏色 */

	color: #fff;

	}
	</style>
	<script src="https://cdn.staticfile.org/jquery/2.2.4/jquery.min.js"></script>

	<script>

	$(function () {

	var $win = $(window);

	var $backToTop = $('.js-back-to-top');

	// 當用戶滾動到離頂部100像素時，展示回到頂部按鈕

	$win.scroll(function () {

	if ($win.scrollTop() > 300) {

	$backToTop.show();

	} else {

	$backToTop.hide();

	}

	});

	// 當用戶點擊按鈕時，通過動畫效果返回頭部

	$backToTop.click(function () {

	$('html, body').animate({scrollTop: 0}, 200);

	});

	});

	</script>
</head>
<body>
	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-light" style="position:fixed; z-index:999" >
		  <div class="container-fluid">
		    <a class="navbar-brand" href="index.php" style="margin-right: 100px;">林董的線上書店</a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" 
		         id="navbarSupportedContent">
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link active" 
		             aria-current="page" 
		             href="index.php">Store</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="contact.php">Contact</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="about.php">About</a>
		        </li>
		        <li class="nav-item">
		          <?php if (isset($_SESSION['user'])) {?>
		          	<a class="nav-link" 
		             href="member.php">Member</a>
		          <?php }else{ ?>
		          <a class="nav-link" 
		             href="login.php">Login</a>
		          <?php } ?>
		        </li>
		      </ul>
		    </div>
		  </div>
		</nav>
		<div style="display: flex; justify-content: center;">
			<form action="search.php"
				method="get" 
				style="width: 60%;margin-top:90px;">
			<div class="input-group my-5">
				<input type="text" 
						class="form-control"
						name="key" 
						placeholder="Search Book..." 
						aria-label="Search Book..." 
						aria-describedby="basic-addon2">
				<button class="input-group-text
								btn btn-primary" 
						id="basic-addon2">
						<img src="img/search.png"
							width="20">
				</button>
			</div>
			</form>
		</div>
	    <div class="container-fluid">
		<div class="row">
		<div class="col-md-12">
			<div class="row">
			<div class="col-md-4 gray-background" style="height: 472.5px;">
			<h2 style="padding:20px;">
			林董語錄
			</h2>
			<hr>
			<p>
			&nbsp;&nbsp;&nbsp;&nbsp;
			我二十歲要成為億萬富翁，我已經成功了一半<br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;我二十了
			</p>
			<hr>
			<p>
			&nbsp;&nbsp;&nbsp;&nbsp;
			葡萄牙跟西班牙中間是什麼<br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;牙縫
			</p>
			<hr>
			<p>
			&nbsp;&nbsp;&nbsp;&nbsp;
			知道怎麼成為有趣的人嗎?<br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			來林董家買書~~
			</p>
			<hr>
			<p>
			<a class="btn" href="about.php"> 
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			--> 瞭解更多林董的故事 </a>
			</p>
			</div>
			<div class="col-md-8">
			<div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
			<ol class="carousel-indicators">
			<li data-bs-target="#carouselExample" data-bs-slide-to="0" class="active"></li>
			<li data-bs-target="#carouselExample" data-bs-slide-to="1"></li>
			<li data-bs-target="#carouselExample" data-bs-slide-to="2"></li>
			</ol>
			<div class="carousel-inner">
			<div class="carousel-item active">
			<img src="img/5.jpg" class="d-block w-100" alt="Carousel Image 1">
			</div>
			<div class="carousel-item">
			<img src="img/10.jpg" class="d-block w-100" alt="Carousel Image 2">
			</div>
			<div class="carousel-item">
			<img src="img/15.jpg" class="d-block w-100" alt="Carousel Image 3">
			</div>
			</div>
			<a class="carousel-control-prev" href="#carouselExample" role="button" data-bs-slide="prev">
			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
			<span class="visually-hidden">Previous</span>
			</a>
			<a class="carousel-control-next" href="#carouselExample" role="button" data-bs-slide="next">
			<span class="carousel-control-next-icon" aria-hidden="true"></span>
			<span class="visually-hidden">Next</span>
			</a>
			</div>
			</div>
			</div>
			</div>
		</div>
		<div class="d-flex pt-3">
			<?php if ($books == 0){ ?>
				<div class="alert alert-warning 
        	            text-center p-5" 
        	     role="alert">
        	     <img src="img/empty.png" 
        	          width="100">
        	     <br>
			    There is no book in the database
		       </div>
			<?php }else{ ?>
				<div class="pdf-list d-flex flex-wrap">
					<?php foreach ($books as $index => $book): ?>
						<div class="card m-1" style="max-width: 250px;">
							<img src="<?php echo $book['Image']; ?>" class="card-img-top" style="width: 250px;">
							<div class="card-body" style="display: flex; flex-direction: column;">
								<h5 class="card-title" style="flex-shrink: 0; word-break: break-word;">
									<?=$book['book_title']?>
								</h5>
								<p class="card-text">
									<i><b>By: <?php echo $book['book_author'];?><br></b></i>
									<i><b>Category: <?php echo $book['book_category'];?><br></b></i>
									<i><b>Cover: <?php echo $book['book_cover'];?><br></b></i>
									<i><b>Year: <?php echo $book['year_of_publication'];?><br></b></i>
									<i><b>Price: $<?php echo $book['book_price'];?><br></b></i>
									<i><b style = "color: #ff3030; font-weight: bold; font-size:18px;";>VIP: $<?php echo $book['book_price_vip'];?><br></b></i>
									<i><b>Inventory: <?php echo $book['book_inventory'];?><br></b></i>
								</p>
								<a href="#" class="btn btn-success" style="margin-top: auto;" onclick="checkLogin(event, <?php echo htmlspecialchars(json_encode($book)); ?>)">加入購物車</a>
							</div>
						</div>
						<?php if (($index + 1) % 4 === 0): ?>
							<div class="w-100"></div>
						<?php endif; ?>
					<?php endforeach; ?>
					<script>
					function checkLogin(event, currentBook) {
						event.preventDefault(); // 阻止默认行为，以防止页面跳转

						<?php if (isset($_SESSION['user'])) { ?>
							// 用户已登录，显示确认对话框
							var bookTitle = currentBook['book_title'];
							var cartQuantity = prompt("請輸入要加入購物車的數量：", "1");

							if (cartQuantity != null && cartQuantity !== "") {
								var bookId = currentBook['book_id'];
								var cusId = <?php echo $current_member['cus_id']; ?>;
								var unitPrice;
								if (<?=$current_member['cus_vip_state']?> == 1) {
									unitPrice = currentBook['book_price_vip'];
								} else {
									unitPrice = currentBook['book_price'];
								}
								// 使用AJAX發送POST請求到後端
								var xhr = new XMLHttpRequest();
								var url = 'add_to_cart.php'; // 指定後端處理的URL
								xhr.open('POST', url, true);
								xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
								// 處理AJAX回應
								xhr.onreadystatechange = function() {
									if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
										// 處理後端回應
										var response = xhr.responseText;
										alert(response); // 可以在這裡顯示成功訊息或進行其他操作
									}
								};
								var data = 'book_id=' + bookId + '&cus_id=' + cusId + '&unit_price=' + unitPrice + '&quantity=' + cartQuantity;
								xhr.send(data);
								alert("已將 " + cartQuantity + " 本《" + bookTitle + "》加入購物車！");
							}
						<?php } else { ?>
							// 用户未登录，显示确认对话框
							var confirmRedirect = confirm("是否前往登入？");
							if (confirmRedirect) {
								window.location.href = "login.php";
							}
						<?php } ?>
					}
					</script>
				</div>
			<?php } ?>

			<div class="category ">
				<!-- List of categories -->
				<div class="list-group" style="width: 200px;">
					<?php if ($categories == 0){
						// do nothing
					}else{ ?>
					<a href="#"
					class="list-group-item list-group-item-action active " style="text-align: center; font-size: 24px;">Category</a>
					<?php foreach ($categories as $category ) {?>
					
					<a href="category.php?category_name=<?=$category['category_name']?>"
						class="list-group-item list-group-item-action" style="text-align: center; font-size: 18px;">
						<?=$category['category_name']?></a>
					<?php } } ?>
				</div>
				<br/>
				<!-- List of cover -->
				<div class="list-group">
					<?php if ($covers == 0){
						// do nothing
					}else{ ?>
					<a href="#"
					class="list-group-item list-group-item-action active" style="text-align: center; font-size: 24px;">Cover</a>
					<?php foreach ($covers as $cover ) {?>
					
					<a href="cover.php?cover_name=<?=$cover['cover_name']?>"
						class="list-group-item list-group-item-action" style="text-align: center; font-size: 18px;">
						<?=$cover['cover_name']?></a>
					<?php } } ?>
				</div>
			</div>
		</div>
	</div>
	<button class="js-back-to-top back-to-top" title="回到頭部">&#65085;</button>
</body>
</html>