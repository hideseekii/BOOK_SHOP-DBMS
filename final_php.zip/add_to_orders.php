<?php
// 資料庫連線設定
$servername = "localhost";
$username = "root";
$password = "dbuser";
$dbname = "bookstore";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the parameters from the AJAX request
$address = $_POST['address'];
$method = $_POST['paymentMethod'];
$cusId = $_POST['cus_id'];
$invoiceway = $_POST['invoiceway'];
$couponnum = $_POST['couponnum'];
$isCouponValid = $_POST['isCouponValid'];
$total = $_POST['total'];


if ($isCouponValid == 'true') {
    $stmt = $conn->prepare("INSERT INTO orders (order_address, payment_method, cus_id, invoice_method, order_date, coupon_id, order_total_price) VALUES (?, ?, ?, ?, NOW(), ?, ?)");
    $stmt->bind_param("ssisid", $address, $method, $cusId, $invoiceway, $couponnum, $total);
    $sql = "UPDATE coupon SET coupon_count = coupon_count + 1 WHERE coupon_id = ?";
    $stmt2 = $conn->prepare($sql);
    $stmt2->bind_param("i", $couponnum);
    $stmt3 = $conn->prepare("UPDATE customer SET cus_total_purchase = cus_total_purchase + ? WHERE cus_id = ?");
    $stmt3->bind_param("di", $total, $cusId);
    if ($stmt->execute() && $stmt2->execute() && $stmt3->execute()) {
        echo "已成功送出訂單";
    } else {
        echo "未能成功送出訂單" . $stmt->error;
    }
    $stmt2->close();
    $stmt3->close();
} else {
    $stmt = $conn->prepare("INSERT INTO orders (order_address, payment_method, cus_id, invoice_method, order_date, order_total_price) VALUES (?, ?, ?, ?, NOW(), ?)");
    $stmt->bind_param("ssisd", $address, $method, $cusId, $invoiceway, $total);
    $stmt3 = $conn->prepare("UPDATE customer SET cus_total_purchase = cus_total_purchase + ? WHERE cus_id = ?");
    $stmt3->bind_param("di", $total, $cusId);
    if ($stmt->execute() && $stmt3->execute()) {
        echo "已成功送出訂單";
    } else {
        echo "未能成功送出訂單" . $stmt->error;
    }
    $stmt3->close();
}



$stmt->close();
$conn->close();
?>