<?php
session_start();

if (!isset($_SESSION['user'])) {
    // 如果已經登入，可以執行一些相應的操作，例如重新導向至其他頁面
    header("Location: login.php");
    exit();
}

# Database Connection File
include "db_conn.php";

# Get All books function
$sql  = "SELECT * FROM bookstore ORDER bY book_id DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $books = $stmt->fetchAll();
}else {
   $books = 0;
}

$member_account = $_SESSION['user'];
# Get member information
$sql  = "SELECT * FROM customer WHERE cus_account=?";
$stmt = $conn->prepare($sql);
$stmt->execute([$member_account]);
 
if ($stmt->rowCount() > 0) {
    $current_member = $stmt->fetch();
}else {
    $current_member = 0;
}

# Get all Cart function
$sql  = "SELECT * FROM cart where cart_status = 'unfinished' ORDER bY cart_id";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $cart_items = $stmt->fetchAll();
}else {
	$cart_items = 0;
}

$sql  = "SELECT * FROM cart where cart_status = 'finished' ORDER bY cart_id";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $cart_items2 = $stmt->fetchAll();
}else {
	$cart_items2 = 0;
}


# Get all Orders function
$sql  = "SELECT * FROM orders where order_status = 'finished'ORDER bY order_id";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $orderitems = $stmt->fetchAll();
}else {
	$orderitems = 0;
}

# Get all coupon function
$sql  = "SELECT * FROM coupon ORDER bY coupon_id";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $coupons = $stmt->fetchAll();
}else {
	$coupons = 0;
}



# Get all Orders function
$sql  = "SELECT * FROM orders where order_status = 'unfinished' ORDER bY order_id";
$stmt = $conn->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $orderitems2 = $stmt->fetchAll();
}else {
	$orderitems2 = 0;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>購物車</title>

    <!-- bootstrap 5 CDN-->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

    <!-- bootstrap 5 Js bundle CDN-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    <style>
	.centered-heading {
		text-align: center;
	}
	.centered-container {
        text-align: center;
    }
	.toggle-button {
        display: inline-block;
        text-align: center;
    }
	.w-6 {
    width: 1.5rem;
    }
	.bg-gray-100 {
    --tw-bg-opacity: 1;
    background-color: rgba(220, 221, 225, var(--tw-bg-opacity));
    }
	.bg-purple-100 {
    --tw-bg-opacity: 1;
    background-color: rgba(187, 176, 218, var(--tw-bg-opacity));
    }
    </style>
	<style>
    .navbar {
        height: 100px; /* 调整导航栏的高度 */
		width: 1285px;
    }
    
    .navbar-brand {
        font-size: 40px; /* 调整导航品牌的字体大小 */
    }
    
    .navbar-nav .nav-link {
        font-size: 28px; /* 调整导航链接的字体大小 */
    }
	</style>
</head>
<body>
	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-light" style="position:fixed; z-index:999">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="<?php echo isset($_SESSION['user']) ? 'member.php' : 'index.php'; ?>" style="margin-right: 100px;">林董的線上書店</a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" 
		         id="navbarSupportedContent">
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="<?php echo isset($_SESSION['user']) ? 'member.php' : 'index.php'; ?>">Store</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="contact.php">Contact</a>
		        </li>
		        <li class="nav-item" style="margin-right: 100px;">
		          <a class="nav-link" 
		             href="about.php">About</a>
		        </li>
		        <li class="nav-item dropdown" style="margin-right: 10px;">
					<?php if (isset($_SESSION['user'])){?>
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="img/unnamed.jpg" alt="User" class="user-icon" style="max-width: 40px; border-radius: 50%; margin-top:-5px;">
                        <span class="user-name"><?=$current_member['cus_name']?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
					<li style="text-align: center;"><a class="dropdown-item" href="cart.php">購物車</a></li>
						<li><hr class="dropdown-divider"></li>
						<li  style="text-align: center;"><a class="dropdown-item" href="edit.php">編輯個資</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li  style="text-align: center;"><a class="dropdown-item" href="logout.php">登出</a></li>
                    </ul>
					<?php }else{?>
					<a class="nav-link" 
		            href="login.php">Login</a>
		          <?php } ?>
                </li>
				<li>
					<a href="cart.php">
					<img src="img/cart.png" style="max-width: 40px; border-radius: 0%; margin-top: 10px;" >
					</a>
				</li>
		      </ul>
		    </div>
		  </div>
		</nav>
		<br/>
		<div style="margin-top:100px;">
		<h1 class="centered-heading">購物車</h1>
		</div>
        <table class="table">
            <thead>
                <tr>
					<th class="text-center">項次</th>
                    <th class="text-center" style="width: 400px;">書名</th>
                    <th class="text-center">單價</th>
                    <th class="text-center">數量</th>
                    <th class="text-center">小計</th>
					<th class="text-center">確認</th>
                </tr>
            </thead>
            <tbody>
				<?php 
				$totalSum = 0; // Variable to store the total sum
				$count = 0;
				foreach ($cart_items as $item) {
					if ($item['cus_id'] == $current_member['cus_id']) { 
						$subtotal = $item['unit_price'] * $item['cart_num']; // Calculate subtotal for each item
						$totalSum += $subtotal; // Add the subtotal to the total sum
						$count++;
						?>
						<tr>
							<td class="text-center">
								<div class="bg-gray-100"><?php echo $count; ?></div>
							</td>
							<td class="text-center">
								<?php 
								foreach ($books as $book) {
									if ($book['book_id'] == $item['book_id']) {
										echo $book['book_title'];
										break; // Exit the loop once the matching book is found
									}
								}
							?>
							</td>
							<td class="text-center">$<?php echo $item['unit_price']; ?></td>
							<td class="text-center"><?php echo $item['cart_num']; ?></td>
							<td class="text-center">$<?php echo $subtotal; ?></td>
							<td class="text-center">
								<button onclick="removeCartItem(<?=$item['cart_id']?>)">移除</button>
                            </td>
						</tr>
				<?php }
				} ?>
			</tbody>
			<script>
				function removeCartItem(cartId) {
					var confirmed = confirm('確認刪除?');
					if (confirmed) {
						var xhr = new XMLHttpRequest();
						var url = 'remove_cart_item.php'; // remove_cart_item.php 的 URL
						xhr.open('POST', url, true);
						xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

						// 處理AJAX回應
						xhr.onreadystatechange = function() {
							if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
								// 處理後端回應
								var response = xhr.responseText;
								alert(response); // 可以在這裡顯示成功訊息或進行其他操作
								// 刷新页面
								window.location.reload();
							}
						};

						// 发送 AJAX 请求，将 cartId 发送到后端进行删除操作
						xhr.send('cartId=' + cartId);
					}
					else{
						alert('取消刪除');
					}
				}
			</script>
			<tfoot>
				<tr>
					<?php if ($totalSum == 0): ?>
						<td colspan="5"></td>
						<td class="text-center" style="text-align:right;">您未新增任何商品</td>
						<!-- <td></td> -->
					<?php else: ?>
						<td colspan="4"></td> <!-- 前三个空单元格 -->
						<td class="text-center"><strong>總計：$<?php echo $totalSum; ?></strong></td> <!-- 第四个单元格，向左对齐 -->
						<td class="text-center"><a href="checkout.php" class="btn btn-primary">前往結帳</a></td>
					<?php endif; ?>
				</tr>
			</tfoot>
        </table>
		<br/>
		<div class="centered-container">
			<h1 class="centered-heading">處理中的訂單</h1>
			<?php $count2 = 0;
			foreach ($orderitems2 as $orderitem) {
				$count2++;
				?>
				<div class="bg-purple-100">第<?php echo $count2; ?>筆<?php echo str_repeat('&nbsp;', 4); ?><?php echo $orderitem['order_date']; ?></div>
				<table class="table">
					<thead>
						<tr>
							<th class="text-center">項次</th>
							<th class="text-center" style="width: 500px;">書名</th>
							<th class="text-center">單價</th>
							<th class="text-center">數量</th>
							<th class="text-center">小計</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$totalSum = 0; // Variable to store the total sum
						$count = 0;
						foreach ($cart_items2 as $item) {
							if ($item['cus_id'] == $current_member['cus_id'] && $item['order_id'] == $orderitem['order_id']) {
								$subtotal = $item['unit_price'] * $item['cart_num']; // Calculate subtotal for each item
								$totalSum += $subtotal; // Add the subtotal to the total sum
								$count++;
								?>
								<tr>
									<td class="text-center">
										<div class="bg-gray-100"><?php echo $count; ?></div>
									</td>
									<td class="text-center">
										<?php
										foreach ($books as $book) {
											if ($book['book_id'] == $item['book_id']) {
												echo $book['book_title'];
												break; // Exit the loop once the matching book is found
											}
										}
										?>
									</td>
									<td class="text-center">$<?php echo $item['unit_price']; ?></td>
									<td class="text-center"><?php echo $item['cart_num']; ?></td>
									<td class="text-center">$<?php echo $subtotal; ?></td>
								</tr>
						<?php
							}
						}
						?>
					</tbody>
					<tfoot>
						<tr>
							<td colspan="4"></td> <!-- 前三个空单元格 -->
							<?php $money=0;
								if($orderitem['coupon_id']){
									foreach($coupons as $coupon){
										if($orderitem['coupon_id']==$coupon['coupon_id']){
											$money = $coupon['coupon_discount'];
										}
								}
							}?>
							<td class="text-center">
								<strong>
									總計：$<?php echo $totalSum; ?>
									<?php if($money!=0){?>
										<br/>
										折價後：$<?php echo $totalSum-$money;?>
									<?php }?>
									<br/>
									<button onclick="cancelorder(<?=$orderitem['order_id']?>)">取消訂單</button>
								</strong>
							</td> <!-- 第四个单元格，向左对齐 -->
						</tr>
					</tfoot>
					<script>
						function cancelorder(orderId) {
							var confirmed = confirm('確認取消訂單?');
							if (confirmed) {
								var xhr = new XMLHttpRequest();
								var url = 'cancel_order.php'; // remove_cart_item.php 的 URL
								xhr.open('POST', url, true);
								xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

								// 處理AJAX回應
								xhr.onreadystatechange = function() {
									if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
										// 處理後端回應
										var response = xhr.responseText;
										alert(response); // 可以在這裡顯示成功訊息或進行其他操作
										// 刷新页面
										window.location.reload();
									}
								};

								// 发送 AJAX 请求，将 cartId 发送到后端进行删除操作
								xhr.send('orderId=' + orderId);
							}
							else{
								alert('取消動作');
							}
						}
					</script>
				</table>
			<?php
			}?>
		</div>
		<br/><br/><br/><br/>
		<div class="centered-container">
			<h1 class="centered-heading">歷史購物車</h1>
			<button id="toggleButton" class="toggle-button">顯示歷史購物車內容</button>
			<br/>
			<?php $count2 = 0;?>
			<div id="cartContent" style="display: none;">
				<?php foreach ($orderitems as $orderitem) {
					$showTable = false;
					foreach ($cart_items2 as $item) {
						if ($item['cus_id'] == $current_member['cus_id'] && $item['order_id'] == $orderitem['order_id']) {
							$showTable = true;
							break;
						}
					}
					if ($showTable) {
						$count2++;
						?>
						<div class="bg-purple-100">第<?php echo $count2; ?>筆<?php echo str_repeat('&nbsp;', 4); ?><?php echo $orderitem['order_date']; ?></div>
						<table class="table">
							<thead>
								<tr>
									<th class="text-center">項次</th>
									<th class="text-center" style="width: 500px;">書名</th>
									<th class="text-center">單價</th>
									<th class="text-center">數量</th>
									<th class="text-center">小計</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$totalSum = 0; // Variable to store the total sum
								$count = 0;
								foreach ($cart_items2 as $item) {
									if ($item['cus_id'] == $current_member['cus_id'] && $item['order_id'] == $orderitem['order_id']) {
										$subtotal = $item['unit_price'] * $item['cart_num']; // Calculate subtotal for each item
										$totalSum += $subtotal; // Add the subtotal to the total sum
										$count++;
										?>
										<tr>
											<td class="text-center">
												<div class="bg-gray-100"><?php echo $count; ?></div>
											</td>
											<td class="text-center">
												<?php
												foreach ($books as $book) {
													if ($book['book_id'] == $item['book_id']) {
														echo $book['book_title'];
														break; // Exit the loop once the matching book is found
													}
												}
												?>
											</td>
											<td class="text-center">$<?php echo $item['unit_price']; ?></td>
											<td class="text-center"><?php echo $item['cart_num']; ?></td>
											<td class="text-center">$<?php echo $subtotal; ?></td>
										</tr>
								<?php
									}
								}
								?>
							</tbody>
							<tfoot>
								<tr>
									<td colspan="4"></td> <!-- 前三个空单元格 -->
									<?php $money=0;
										if($orderitem['coupon_id']){
											foreach($coupons as $coupon){
												if($orderitem['coupon_id']==$coupon['coupon_id']){
													$money = $coupon['coupon_discount'];
												}
										}
									}?>
									<td class="text-center">
										<strong>
											總計：$<?php echo $totalSum; ?>
											<?php if($money!=0){?>
												<br/>
												折價後：$<?php echo $totalSum-$money;?>
											<?php }?>
										</strong>
									</td> <!-- 第四个单元格，向左对齐 -->
								</tr>
							</tfoot>
						</table>
				<?php
					}
				}
				?>
			</div>
		</div>
		<script>
			// Add click event listener to toggle button
			var toggleButton = document.getElementById('toggleButton');
			var cartContent = document.getElementById('cartContent');

			toggleButton.addEventListener('click', function() {
				if (cartContent.style.display === 'none') {
					cartContent.style.display = 'block';
					toggleButton.textContent = '隱藏歷史購物車內容';
				} else {
					cartContent.style.display = 'none';
					toggleButton.textContent = '顯示歷史購物車內容';
				}
			});
		</script>
</body>
</html>